import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Util {



	public static float calc(int n){
		float res=0;
		for(int i=1; i<=n;i++){
			res+=Math.log(i);
		}
		return res;
	}



	public static void writeGraph2(Graph g, String outFile) throws FileNotFoundException { 

		StringBuilder sb = new StringBuilder();
		String ls = System.getProperty("line.separator");
		String dl = ls + ls;
		sb.append("digraph dbn{" + dl);


		for(int i=0; i<g.n; i++) {
			for(int j:g.adj.get(i)) {
				sb.append(""+(i+1)+"->"+""+(j+1)+";");
				System.out.println(""+(i+1) +"->"+""+(j+1)+";");
				sb.append(dl);
			}

		}

		for(int i=0; i<g.n;i++) {
			sb.append(""+(i+1)+";");
			sb.append(dl);
		}




		sb.append("}");

		File f = new File(outFile + ".dot");

		if (f.isFile()) {
			System.err.println("Warning: overwriting to " + outFile + ".");
		}

		PrintWriter w = new PrintWriter(f);

		w.println(sb);
		w.close();

	}


	public static double Mean( double[] obs) {

		double sum=0;

		for(int i=0; i <obs.length ; i++) {
			sum+=obs[i];

		}


		sum= sum/(double)obs.length;
		return sum;
	}


	public static double StandDes( double[] obs,double mean) {

		double sum=0;

		for(int i=0; i <obs.length ; i++) {
			sum+= Math.pow(obs[i]-mean,2);

		}
		sum= Math.sqrt(sum/(obs.length-1));
		return sum;
	}


	public static void writeToFile(String fileName, String contents) throws FileNotFoundException {
		File f = new File(fileName);
		if (f.isFile()) {
			System.err.println("Warning: overwriting to " + fileName + ".");
		}
		PrintWriter w = new PrintWriter(f);
		w.println(contents);
		w.close();

	}







	public static void writeGraph(Graph g, String outFile, ArrayList<String> variables)throws FileNotFoundException { 

		StringBuilder sb = new StringBuilder();
		String ls = System.getProperty("line.separator");
		String dl = ls + ls;
		sb.append("digraph dbn{" + dl);

		System.out.println("digraph dbn{");

		for(int i=0; i<g.n; i++) {
			for(int j:g.adj.get(i)) {
				sb.append(variables.get(i)+"->"+variables.get(j)+";");
				System.out.println(variables.get(i)+"->"+variables.get(j)+";");
				sb.append(dl);
			}

		}

		for(int i=0; i<g.n;i++) {
			sb.append(variables.get(i) +";");
			System.out.println(variables.get(i) +";");
			sb.append(dl);
		}




		sb.append("}");

		File f = new File(outFile + ".dot");

		if (f.isFile()) {
			System.err.println("Warning: overwriting to " + outFile + ".");
		}

		PrintWriter w = new PrintWriter(f);

		w.println(sb);
		w.close();

	}












}
