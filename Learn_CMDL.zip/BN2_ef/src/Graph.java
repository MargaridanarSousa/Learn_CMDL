import java.lang.Integer;
import java.util.*;

public class Graph {

	protected  int n;
	protected  ArrayList<ArrayList<Integer>> adj;
	protected  ArrayList<ArrayList<Integer>> nodes;
	protected  ArrayList<ArrayList<Integer>> parents;

	public  Graph(int n0){
		n = n0;
		adj = new ArrayList<ArrayList<Integer>>();
		nodes = new ArrayList<ArrayList<Integer>>();
		parents= new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < n; i++){
			ArrayList<Integer> adj_i= new ArrayList<Integer>();
			ArrayList<Integer> l = new ArrayList<Integer>();
			ArrayList<Integer> p_i= new ArrayList<Integer>();

			l.add(i);
			adj.add(adj_i);
			nodes.add(l);
			parents.add(p_i);
		}
	}

	public boolean istree() {
		boolean b =true;
		int i =0;

		while (b==true && i <n) {
			if(parents.get(i).size()>0) b=false;
			i+=1;

		}

		return b;
	}



	public Graph(Graph g){
		n= g.n;
		adj= new ArrayList<ArrayList<Integer>>();
		nodes= new ArrayList<ArrayList<Integer>>();
		parents= new ArrayList<ArrayList<Integer>>();
		for(int i=0; i<n;i++) {
			ArrayList<Integer> a= new  ArrayList<Integer>(g.adj.get(i));
			ArrayList<Integer> n= new  ArrayList<Integer>(g.nodes.get(i));
			ArrayList<Integer> p= new  ArrayList<Integer>(g.parents.get(i));
			adj.add(a);
			nodes.add(n);
			parents.add(p);

		}
	}

	public void addC() {
		n=n+1;
		ArrayList<Integer> no = new ArrayList<Integer>();
		no.add(n-1);
		nodes.add(no);
		ArrayList<Integer> a = new ArrayList<Integer>();
		adj.add(a);
		ArrayList<Integer> p = new ArrayList<Integer>();
		parents.add(p);


	}

	public void takeC() {
		n=n-1;
		nodes.remove(n);
		adj.remove(n);
		parents.remove(n);

	}

	public int getn(){
		return n;
	}

	public ArrayList<ArrayList<Integer>> getadj(){
		return adj;
	}


	public ArrayList<ArrayList<Integer>> getnodes(){
		return nodes;
	}
	
	public ArrayList<ArrayList<Integer>> getParents(){
		return parents;	
	}


	public void addEdge(int i, int j) {
		adj.get(i).add(j);
		parents.get(j).add(i);
	}


	public void removeEdge(int i, int j) {
		if(adj.get(i).contains(j)) {
			adj.get(i).remove(new Integer(j));
		}


		if(parents.get(j).contains(i)) {
			parents.get(j).remove(new Integer(i));
		}


	}

	public void flipEdge(int i, int j){
		if(adj.get(i).contains(j)){
			removeEdge(i,j);
			addEdge(j,i);

		}
	}

	public boolean hasEdge(int i, int j) {
		return adj.get(i).contains(j);
	}

	ArrayList<Integer> outEdges(int i) {
		return adj.get(i);
	}

	ArrayList<Integer> inEdges(int i) {
		return parents.get(i);
	}

	ArrayList<ArrayList<Integer>> parents(int i){
		ArrayList<ArrayList<Integer>> p = new ArrayList<ArrayList<Integer>>();
		for(int j=0; j<parents.get(i).size();j++) {
			p.add(nodes.get(parents.get(i).get(j)));}
		return p;}


	//Generates a covering graph with V nodes and E edges
	public Graph(int V, int E) {

		if (E > (long) V*(V-1)) throw new IllegalArgumentException("Too many edges");
		if (E < 0)              throw new IllegalArgumentException("Too few edges");
		n=V;
		adj = new ArrayList<ArrayList<Integer>>();
		nodes = new ArrayList<ArrayList<Integer>>();
		parents = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> perm_nodes= new ArrayList<Integer>();
		for (int i = 0; i < n; i++){
			ArrayList<Integer> adji= new ArrayList<Integer>();
			ArrayList<Integer> list = new ArrayList<Integer>();
			ArrayList<Integer> p= new ArrayList<Integer>();
			list.add(i);
			nodes.add(list);
			adj.add(adji);
			parents.add(p);
			perm_nodes.add(i);

		}

		java.util.Collections.shuffle(perm_nodes);


		Random rand = new Random();
		int m=0;
		while (m < E) {
			int v = rand.nextInt(n);
			int w = rand.nextInt(n);

			if (v<w && !adj.get(perm_nodes.get(v)).contains(w) && !parents.get(perm_nodes.get(w)).contains(perm_nodes.get(v))) {
				addEdge(perm_nodes.get(v),perm_nodes.get(w)); m++;
			}
		}

/*
		if(!isCovering()){
			for(int i=0; i<n ; i++){
				for(int j=i+1; j<n;j++ ){
					int h=0;
					while(h<parents.get(j).size()){
						if(parents.get(i).contains(parents.get(j).get(h))){

							for(int k=0; k<parents.get(j).size();k++){
								if(!parents.get(i).contains(parents.get(j).get(k)) && parents.get(j).get(k)!=i && !parents.get(j).contains(i)  ) addEdge(parents.get(j).get(k),i);
							}
							for(int l=0; l<parents.get(i).size();l++){
								if(!parents.get(j).contains(parents.get(i).get(l)) && parents.get(i).get(l)!=i && !parents.get(j).contains(i) ) addEdge(parents.get(i).get(l),j);
							}
							break;
						}
						h++;
					}

				}
			}
		} */
		

	}



	/* Computes the SCC of the graph by Tarjan's Algorithm */	
	public ArrayList<ArrayList<Integer>> TarjanSCC() {

		ArrayList<ArrayList<Integer>> sccComp;
		boolean[] marked;        // marked[v] = has v been visited?
		int[] low;               // low[v] = low number of v
		int pre;                 // preorder number counter
		int count;               // number of strongly-connected components
		Stack<Integer> stack;    // stack

		sccComp = new ArrayList<>();
		int n= this.n;
		pre=0;
		count=0;
		marked = new boolean[n];
		stack = new Stack<Integer>();
		low = new int[n];
		for (int v = 0; v <n ; v++) {
			if (!marked[v]) dfs(v,marked,low,pre,count,stack,sccComp);
		}
		return sccComp;
	}

	/* Computes the depth-first search */
	private void dfs(int v,boolean[] marked,int[] low, int pre, int count,Stack<Integer> stack,ArrayList<ArrayList<Integer>> sccComp) { 

		marked[v] = true;
		low[v] = pre++;
		int min = low[v];
		stack.push(v);
		for (int w : this.outEdges(v)) {

			if (!marked[w]) dfs(w,marked,low,pre,count,stack,sccComp);

			if (low[w] < min) min = low[w];
		}
		if (min < low[v]) {
			low[v] = min;
			return;
		}
		ArrayList<Integer> component = new ArrayList<Integer>();
		int w;
		do {
			w = stack.pop();
			component.add(w);
			low[w] =this.n;
		} while (w != v);
		count++;
		sccComp.add(component);
	}



	/* Is the graph a DAG ? */

	public boolean isDAG(){
		boolean b=false;
		for(int i=0; i<adj.size(); i++){
			if(adj.get(i).contains(i)) return b;
		}
		return TarjanSCC().size()==n;
	}
	
	
	// Returns covering Cg
	public ArrayList<ArrayList<Integer>> Covering(){
		
		ArrayList<ArrayList<Integer>> Cg= new ArrayList<ArrayList<Integer>>();
		
		
		for(int i=0;i<n;i++) {
			
			ArrayList<Integer> C = new ArrayList<Integer>();
			C.add(i);
			C.addAll(parents.get(i));
			Cg.add(C);
		}
		
		return Cg;
		
	}
	
	
	
	/* Is the Graph a Covering Graph ? */
	public boolean isCovering(){
		
		if(isDAG() == false) return false;
		
		Graph forest = new Graph(this);
		forest.forestification();
		
	
		
		ArrayList<ArrayList<Integer>> Cg = Covering();
		

		boolean b = false;
		
		

		for(int i=0; i<forest.getn();i++) {
			
		
			
			
			// Union of the equivalent classes of the node i and its parents
			ArrayList<Integer> union = new ArrayList<Integer>();
			union.addAll(forest.getnodes().get(i));
						
			if (forest.getParents().get(i).size()!=0) union.addAll(forest.getnodes().get(forest.getParents().get(i).get(0)));
		
			
			for(ArrayList<Integer> c: Cg) {
				
				b=false;
				
				for(int u : union) {
										
					if(!c.contains(u)) {
						b=false;
						break;
					}
					
					else b=true;
										
				}
				
				if(b) break;
			
			
			}
			
			
			if(!b) return false;
			
		}	
		
		return true;
		
	}
	


	/* Computes the Forestification relation */
	public void forestification(){


		ArrayList<ArrayList<Integer>> par = new ArrayList<ArrayList<Integer>>();

		for(int i=0;i<n;i++) {
			par.add(new ArrayList(parents.get(i)));
		}

		boolean b=false;

		for(int v=0; v<n ; v++){

			if(par.get(v).size()>=2){
				b=true;
				for(int i=0; i < par.get(v).size()-1 ; i++){

					if(!adj.get(par.get(v).get(i)).contains(par.get(v).get(i+1))) addEdge(parents.get(v).get(i), parents.get(v).get(i+1));
					if(!adj.get(par.get(v).get(i+1)).contains(par.get(v).get(i))) addEdge(parents.get(v).get(i+1), parents.get(v).get(i));
				}
			}
		}
		
		

		if(b){

			ArrayList<ArrayList<Integer>> scc = TarjanSCC();

			Graph g2 = new Graph(scc.size());

			ArrayList<ArrayList<Integer>> nodes_c = new ArrayList<ArrayList<Integer>>();

			for(int i=0; i<scc.size();i++){


				ArrayList<Integer> lista_scc = new ArrayList<Integer>();

				for(int j=scc.get(i).size()-1; j>=0;j--){


					for (int k=nodes.get(scc.get(i).get(j)).size()-1; k>=0; k--){
						lista_scc.add(nodes.get(scc.get(i).get(j)).get(k));
					}
				}
				nodes_c.add(lista_scc);
			}


			g2.nodes=nodes_c;
			
			
			
			
		

			for(int i=0; i < scc.size();i++){
				for(int j=i+1; j<scc.size(); j++){
					for(int k=0; k<scc.get(i).size(); k++){
						for(int l=0; l<scc.get(j).size();l++){


							if(hasEdge(scc.get(i).get(k), scc.get(j).get(l)) && !g2.adj.get(i).contains(j) ){

								g2.addEdge(i,j);
								break;
							}
							

							if(hasEdge(scc.get(j).get(l), scc.get(i).get(k)) && !g2.adj.get(j).contains(i)){

								g2.addEdge(j,i);
								break;

							}
						}
					}
				}
			}
			n=g2.n;
			adj=g2.adj;
			nodes=g2.nodes;
			parents=g2.parents;
			forestification();
		}
	}


	// A recursive function used by topologicalSort
	// From https://www.geeksforgeeks.org/topological-sorting/
	public void topologicalSortUtil(int v, boolean visited[],Stack stack)
	{
		// Mark the current node as visited.
		visited[v] = true;
		Integer i;

		// Recur for all the vertices adjacent to this
		// vertex
		Iterator<Integer> it = adj.get(v).iterator();
		while (it.hasNext())
		{
			i = it.next();
			if (!visited[i])
				topologicalSortUtil(i, visited, stack);
		}

		// Push current vertex to stack which stores result
		stack.push(new Integer(v));
	}



	// The function to do Topological Sort. It uses
	// recursive topologicalSortUtil()
	// From https://www.geeksforgeeks.org/topological-sorting/
	public  ArrayList<Integer>  topologicalSort()
	{
		Stack stack = new Stack();

		// Mark all the vertices as not visited
		boolean visited[] = new boolean[n];
		for (int i = 0; i < n; i++)
			visited[i] = false;

		// Call the recursive helper function to store
		// Topological Sort starting from all vertices
		// one by one
		ArrayList<Integer> topo = new ArrayList<Integer>();
		for (int i = 0; i < n; i++)
			if (visited[i] == false)
				topologicalSortUtil(i, visited, stack);




		while (stack.empty()==false)
			//Integer i = (Integer) stack.pop();
			topo.add((Integer) stack.pop());

		return topo;
	}






	public int Number_edges() {
		int sum=0;
		for(int i=0; i<n;i++) {
			sum+=adj.get(i).size();

		}
		return sum;
	}



	// Paper Chickering 1995
	public ArrayList<ArrayList<Integer>> Order_Edges() {
		ArrayList<ArrayList<Integer>> Ordered = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> topo = topologicalSort();



		// Add all edges in Unordered
		int n_edges = Number_edges();

		while(Ordered.size()<n_edges) {
			//Get y
			int y=0;
			for(int k=0; k<n;k++) {
				ArrayList<Integer> par = parents.get(topo.get(k));
				boolean b =false;
				for(int j=0; j<par.size();j++) {
					ArrayList<Integer> Edge = new ArrayList<Integer>();
					Edge.add(par.get(j));
					Edge.add(topo.get(k));   
					if(!Ordered.contains(Edge)) {
						y=topo.get(k);
						b=true;

						break;


					} 
				}

				if(b) break;
			}

			//Get x
			int max_order=0;
			int max=0;
			for(int k=0; k<parents.get(y).size();k++) {
				ArrayList<Integer> Edge = new ArrayList<Integer>();
				Edge.add(parents.get(y).get(k));
				Edge.add(y);

				if(!Ordered.contains(Edge)) {
					int order=topo.indexOf(parents.get(y).get(k));

					if(order>=max_order) {
						max_order=order;
						max=parents.get(y).get(k);
					}

				}   
			}

			int x=max;
			ArrayList<Integer> edge = new  ArrayList<Integer>();
			edge.add(x);
			edge.add(y);

			Ordered.add(edge);



		}

		return Ordered;

	}


	public ArrayList<Integer> get_lowest_order(ArrayList<ArrayList<Integer>> ordered_edges, ArrayList<Integer> label){
		ArrayList<Integer> Edge = new ArrayList<Integer>();
		for(int i=0; i<ordered_edges.size();i++) {
			if(label.get(i)==2) return ordered_edges.get(i);
		}

		return Edge;
	}


	public ArrayList<ArrayList<Integer>> get_w(ArrayList<ArrayList<Integer>> ordered_edges,ArrayList<Integer> label, int x){
		ArrayList<ArrayList<Integer>> out = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> par = parents.get(x);

		for(int i=0; i<par.size();i++) {
			ArrayList<Integer> Edge = new ArrayList<Integer>();
			Edge.add(par.get(i));
			Edge.add(x);
			int index = ordered_edges.indexOf(Edge);
			if(label.get(index)==1) out.add(Edge);
		}

		return out;

	}



	public ArrayList<ArrayList<Integer>> Find_Compelled(){
		ArrayList<ArrayList<Integer>> ordered_edges = Order_Edges();
		int n_edges = Number_edges();


		ArrayList<ArrayList<Integer>> compelled = new ArrayList<ArrayList<Integer>>();

		ArrayList<Integer> label = new ArrayList<Integer>();


		// Labels:
		// 2--> UNKNOWN
		// 1 ---> COMPELLED
		// 0---> NOT COMPELLED


		//label every edge as unknown
		for(int i=0; i<n_edges;i++) {
			label.add(2);
		}

		while(label.contains(2)) {
			ArrayList<Integer> lowest_unknown = get_lowest_order(ordered_edges,label);

			int x= lowest_unknown.get(0);
			int y= lowest_unknown.get(1);

			// Get all edges w->x
			ArrayList<ArrayList<Integer>> list_w = get_w(ordered_edges,label,x);

			for(ArrayList<Integer> a:list_w) {
				int w=a.get(0);
				if(!parents.get(y).contains(w)) {
					for(int e:parents.get(y)) {
						ArrayList<Integer> Edge = new ArrayList<Integer>();
						Edge.add(e);
						Edge.add(y);
						int ind= ordered_edges.indexOf(Edge);
						label.set(ind,1);
					}

				}

				else {
					ArrayList<Integer> Edge = new ArrayList<Integer>();
					Edge.add(w);
					Edge.add(y);
					int ind = ordered_edges.indexOf(Edge);
					label.set(ind, 1);

				}

			}
			boolean b=false;
			for(int z:parents.get(y)) {

				if(z!=x && !parents.get(x).contains(z)) {
					b=true;
					break;
				}

			}

			if(b) {
				for(int e:parents.get(y)) {

					ArrayList<Integer> Edge = new ArrayList<Integer>();

					// System.out.println("e "+e);
					// System.out.println("y "+y);

					//System.out.println("ordered_edges" + ordered_edges);


					Edge.add(e);
					Edge.add(y);
					int ind = ordered_edges.indexOf(Edge);
					if(label.get(ind)==2) label.set(ind, 1);

				}
			}

			else {

				for(int e:parents.get(y)) {

					ArrayList<Integer> Edge = new ArrayList<Integer>();

					// System.out.println("e "+e);
					// System.out.println("y "+y);

					//System.out.println("ordered_edges" + ordered_edges);


					Edge.add(e);
					Edge.add(y);
					int ind = ordered_edges.indexOf(Edge);
					if(label.get(ind)==2) label.set(ind, 0);

				}

			}

			//System.out.println("label "+label);

		}


		for(int i=0; i<ordered_edges.size();i++) {
			if(label.get(i)==1) compelled.add(ordered_edges.get(i));
		}

		return compelled; 

	}



	// Generates parameters for Graph g; Each attribute has s states. 

	public static Hashtable<ArrayList<Integer>,Double> gen_prob(Graph g, int s){

		Random r = new Random();

		// Guardar P(X|Y)
		Hashtable<ArrayList<Integer>,Double> h = new Hashtable<ArrayList<Integer>,Double>();

		for (int i=0; i<g.n;i++){
			if(g.parents.get(i).size()>0){
				for (int j=0; j<Math.pow(s,g.parents(i).size());j++){
					float sum = 0;
					for(int k=0; k<s ; k++) {
						Double t =r.nextDouble();
						ArrayList<Integer> l = new ArrayList<Integer>();
						l.add(i);
						l.add(j);
						l.add(k);
						h.put(l,t);
						sum+=t;
					}

					for (int k=0;k<s;k++){
						ArrayList<Integer> l = new ArrayList<Integer>();
						l.add(i);
						l.add(j);
						l.add(k);
						double f = h.get(l)/sum;
						h.put(l, f);

					}

				}
			}

			else {
				float sum2 =0;
				for(int j=0; j<s; j++) {
					Double t=r.nextDouble();
					ArrayList<Integer> l = new ArrayList<Integer>();
					l.add(i);
					l.add(j);
					h.put(l, t);
					sum2+=t;

				}

				for(int j=0; j<s; j++) {
					ArrayList<Integer> l = new ArrayList<Integer>();
					l.add(i);
					l.add(j);
					Double f =h.get(l)/sum2;
					h.put(l, f);

				}

			}



		}

		return h;


	}

	// Samples n instances from Graph g with parameters h

	public static ArrayList<ArrayList<Integer>> getinstances(Graph g,int n,Hashtable<ArrayList<Integer>,Double> h,int s){


		Random r = new Random();

		ArrayList<ArrayList<Integer>> set = new ArrayList<ArrayList<Integer>>();

		for(int m=0; m<n;m++){

			ArrayList<Integer> instance = new ArrayList<Integer>();


			for(int i=0; i<g.n; i++){
				instance.add(0);
			}



			for (int i=0; i<g.n;i++){

				if(g.parents.get(i).size()==0){


					double f = r.nextDouble();
					double sum =0;

					for(int p=0; p < s; p++) {
						ArrayList<Integer> l= new ArrayList<Integer>();
						l.add(i);
						l.add(p);
						Double prob = h.get(l);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;

					}


				}
			}

			for (int i=0; i<g.n;i++){
				if(g.parents.get(i).size()!=0){

					int valor_j=instance.get(g.parents.get(i).get(0));
					for (int j=1; j<g.parents(i).size();j++){
						valor_j=valor_j*2;
						valor_j=valor_j+instance.get(g.parents.get(i).get(j));
					}
					float f = r.nextFloat();
					float sum =0;

					for(int p=0; p < s; p++) {
						ArrayList<Integer> l2= new ArrayList<Integer>();
						l2.add(i);
						l2.add(valor_j);
						l2.add(p);
						Double prob = h.get(l2);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;

					}
				}

			}
			set.add(instance);

		}

		return set;
	}



	//Adds n to instances from Graph g with parameters h

	public static ArrayList<ArrayList<Integer>> addinstances(Graph g,int n,ArrayList<ArrayList<Integer>> instances,Hashtable<ArrayList<Integer>,Double> h,int s){

		Random r = new Random();
		//r.setSeed(2);

		for(int m=0; m<n;m++){

			ArrayList<Integer> instance = new ArrayList<Integer>();


			for(int i=0; i<g.nodes.size(); i++){
				instance.add(0);
			}

			for (int i=0; i<g.n;i++){

				if(g.parents.get(i).size()==0){


					float f = r.nextFloat();
					float sum =0;

					for(int p=0; p < s; p++) {
						ArrayList<Integer> l= new ArrayList<Integer>();
						l.add(i);
						l.add(p);
						Double prob = h.get(l);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;

					}




				}
			}

			for (int i=0; i<g.nodes.size();i++){
				if(g.inEdges(i).size()>0){


					int valor_j=instance.get(g.inEdges(i).get(0));
					for (int j=1; j<g.parents(i).size();j++){
						valor_j=valor_j*2;
						valor_j=valor_j+instance.get(g.inEdges(i).get(j));
					}


					double f = r.nextDouble();
					double sum =0;

					for(int p=0; p < s; p++) {
						ArrayList<Integer> l2= new ArrayList<Integer>();
						l2.add(i);
						l2.add(valor_j);
						l2.add(p);
						Double prob = h.get(l2);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;

					}



				}

			}
			instances.add(instance);

		}

		return instances;

	}



	public static double Added_Edges2(Graph g_true,Graph g_learned) {

		double sum =0;

		for(int i=0; i< g_learned.n; i++) {
			for(int j:g_learned.adj.get(i)) {

				if(!g_true.adj.get(i).contains(j) && ! g_true.parents.get(i).contains(j)) sum+=1; 

			}


			for(int k:g_learned.parents.get(i)) {

				if(!g_true.adj.get(i).contains(k) && !g_true.parents.get(i).contains(k)) sum+=1; 

			}

		}
		sum=sum*0.5;
		return sum;

	}




	public static double Deleted_Edges2(Graph g_true, Graph g_learned) {

		double sum =0;

		for(int i=0; i< g_true.n; i++) {
			for(int j:g_true.adj.get(i)) {

				if(!g_learned.adj.get(i).contains(j) && !g_learned.parents.get(i).contains(j)) sum+=1; 

			}


			for(int k:g_true.parents.get(i)) {

				if(!g_learned.adj.get(i).contains(k) && !g_learned.parents.get(i).contains(k)) sum+=1; 

			}

		}
		sum=sum*0.5;
		return sum;

	}




	public static double Inverted_Edges2(Graph g_true, Graph g_learned) {

		double sum =0;

		ArrayList<ArrayList<Integer>> compelled_learned = g_learned.Find_Compelled();

		ArrayList<ArrayList<Integer>> compelled_true = g_true.Find_Compelled();


		//int i=2;

		for(int i=0; i<g_learned.n;i++) {

			for(int j:g_true.parents.get(i)) {

				ArrayList<Integer> edge = new ArrayList<Integer>();
				edge.add(j);
				edge.add(i);

				ArrayList<Integer> reverse_edge = new ArrayList<Integer>();
				reverse_edge.add(i);
				reverse_edge.add(j);

				if(compelled_true.contains(edge) && !compelled_learned.contains(edge)&& !compelled_learned.contains(reverse_edge)  && (g_learned.adj.get(i).contains(j) ||  g_learned.parents.get(i).contains(j))) {
					sum+=1;
				}



				if(compelled_true.contains(edge) && compelled_learned.contains(reverse_edge)) {
					sum+=1;
				}




			}


			for(int k:g_learned.parents.get(i)) {
				ArrayList<Integer> edge = new ArrayList<Integer>();
				edge.add(k);
				edge.add(i);

				ArrayList<Integer> reverse_edge = new ArrayList<Integer>();
				reverse_edge.add(i);
				reverse_edge.add(k);


				if(compelled_learned.contains(edge) && !compelled_true.contains(edge) && !compelled_true.contains(reverse_edge) && (g_learned.adj.get(i).contains(k) ||  g_true.parents.get(i).contains(k))) sum+=1;

			}
		}

		return sum;

	}







	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adj == null) ? 0 : adj.hashCode());
		result = prime * result + n;
		result = prime * result + ((nodes == null) ? 0 : nodes.hashCode());
		result = prime * result + ((parents == null) ? 0 : parents.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Graph other = (Graph) obj;
		if (adj == null) {
			if (other.adj != null)
				return false;
		} else if (!adj.equals(other.adj))
			return false;
		if (n != other.n)
			return false;
		if (nodes == null) {
			if (other.nodes != null)
				return false;
		} else if (!nodes.equals(other.nodes))
			return false;
		if (parents == null) {
			if (other.parents != null)
				return false;
		} else if (!parents.equals(other.parents))
			return false;
		return true;
	}







}
	