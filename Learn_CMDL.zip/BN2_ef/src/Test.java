import java.util.ArrayList;

public class Test {

	public static float test(BN b,Data data,ArrayList<ArrayList<Integer>> instances){

		int n_instances= instances.size();

		float[][]  teta= b.teta2(instances);


		ArrayList<Integer> est = new ArrayList<Integer>();

		float score=0;

		for(int i=0; i<n_instances; i++){

			ArrayList<Double> v = new ArrayList<Double>();

			for(int h=0; h< data.list_r.get(b.n-1)+1;h++){
				v.add(Math.log((double)teta[b.n-1][h]));
			}


			for(int j=0; j<b.n-1;j++){


				int valor_k=instances.get(i).get(b.nodes_rv.get(j).attributes[0].i); 

				int valor_j=0;

				if(b.g.parents.get(j).size()>2) {

					valor_j= instances.get(i).get(b.parents_rv.get(j).get(0).attributes[0].i);

					for(int m=1; m<b.g.parents.get(j).size()-1;m++){
						valor_j=valor_j*b.parents_rv.get(j).get(m).attributes[0].r;
						valor_j=valor_j+ instances.get(i).get(b.parents_rv.get(j).get(m).attributes[0].i);
					}

				}



				for(int c=0; c<data.list_r.get(b.n-1)+1;c++){
					int valor_j2=valor_j;

					if(b.parents_rv.get(j).get(0).n>1) {

						valor_j2=valor_j2*(data.list_r.get(b.n-1)+1);
						valor_j2=valor_j2+c;


					}

					else valor_j2=c;


					v.set(c, v.get(c)+Math.log(teta[j][(valor_j2)*b.nodes_rv.get(j).r+valor_k]));
				}



			}

			double um=-999999999;
			int m=0;

			for(int c=0; c<data.list_r.get(b.n-1)+1;c++){
				if(v.get(c)>um){
					um=v.get(c);
					m=c;
				}
			}

			est.add(m);

			if(m==instances.get(i).get(b.n-1)) score+=1;

		}   





		score= score/((float)n_instances);




		return score;



	}









}
