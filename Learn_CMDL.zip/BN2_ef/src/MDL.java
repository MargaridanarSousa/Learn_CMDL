import java.util.ArrayList;


public class MDL extends Score {

	@Override
	public double evaluate(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {

		float[][]  conf = by.Configuracao(instances);
		float[][]  nij = by.Nij(instances,conf);
		double sum=0;
		double d1=1,d2=1;

		for(int i=0; i<by.n;i++){

			for(int j=0; j<by.nodes_rv.get(i).q; j++){

				for(int r=0; r< by.nodes_rv.get(i).r; r++){

					d1= conf[i][j*by.nodes_rv.get(i).r+r];
					d2=(double) nij[i][j];

					if(d1!=0) sum+=d1*(Math.log(d1)/Math.log(2)-Math.log(d2)/Math.log(2));

				}
			}

			sum-= 0.5*(Math.log(instances.size())/Math.log(2))*(by.nodes_rv.get(i).r-1)*by.nodes_rv.get(i).q;

		}


		return sum;
	}



	@Override
	public double[] param(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {


		double[] out = new double[2];
		float[][]  conf = by.Configuracao(instances);
		float[][]  nij = by.Nij(instances,conf);
		double ll=0;
		double par=0;
		double d1=1;
		double d2=1;


		for(int i=0; i<by.n;i++){

			for(int j=0; j<by.nodes_rv.get(i).q; j++){

				for(int r=0; r< by.nodes_rv.get(i).r; r++){

					d1= conf[i][j*by.nodes_rv.get(i).r+r];
					d2=(double) nij[i][j];

					if(d1!=0) ll+=d1*(Math.log(d1)/Math.log(2)-Math.log(d2)/Math.log(2));

				}
			}

			par-= 0.5*(Math.log(instances.size())/Math.log(2))*(by.nodes_rv.get(i).r-1)*by.nodes_rv.get(i).q;

		}
		out[0]=par;
		out[1]=ll;
		return out;
	}





}
