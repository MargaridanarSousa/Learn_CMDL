public class RandVar {
	
	   protected int i;
	    protected int r;
	     
	    public RandVar(){
	        i=0;
	        r=0; }
	    
	    public RandVar(int ii, int rr ){
	    	i=ii;
	    	r=rr;
	    }
	    
	    public RandVar(RandVar rv){
	    	i = new Integer(rv.i);
	    	r= new Integer(rv.r);
	    	
	    }
	    

		@Override
		public String toString() {
			return "RandVar [i=" + i + "]";
		}

		@Override
		public int hashCode() {
			// TODO Auto-generated method stub
			return super.hashCode();
		}

		@Override
		public boolean equals(Object obj) {
			// TODO Auto-generated method stub
			return super.equals(obj);
		}

	
		
		
		
		
	    
	    

}