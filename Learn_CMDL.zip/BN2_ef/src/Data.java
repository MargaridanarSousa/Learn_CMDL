import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;
import java.io.File;
import java.io.IOException;
import java.lang.Math;

public class Data {

	protected RandVect X;
	protected int n_nodes;
	protected int n_train;
	protected ArrayList<ArrayList<Integer>> instances_train;
	protected ArrayList<ArrayList<Integer>> instances_train_total;
	protected ArrayList<ArrayList<Integer>> instances_test;
	protected ArrayList<ArrayList<Integer>> instances_test_total;
	protected ArrayList<ArrayList<Integer>> instances;
	protected ArrayList<ArrayList<Integer>> instances_total;
	protected int n_instances;
	protected String string;
	protected ArrayList<String> variables;   /* List of variables */
	protected ArrayList<Integer> list_r;



	// Reads File with name string

	public Data(String string) throws IOException {

		Scanner scanner = new Scanner(new File(string));

		scanner.useDelimiter(",");

		Scanner scanner_var = new Scanner(scanner.nextLine());
		scanner_var.useDelimiter(",");

		ArrayList<String> variables2 = new ArrayList<String>();

		int num_nodes =0;

		while(scanner_var.hasNext()){
			variables2.add(scanner_var.next());
			num_nodes++;	 
		}

		scanner_var.close();

		variables=variables2;


		ArrayList<ArrayList<String>> list_string = new ArrayList<ArrayList<String>>();
		for(int i=0; i<num_nodes; i++){
			ArrayList<String> list = new ArrayList<String>();	
			list_string.add(list);
		}
		ArrayList<ArrayList<Integer>> instances_aux = new ArrayList<ArrayList<Integer>>();
		ArrayList<ArrayList<Integer>> instances_aux_tot = new ArrayList<ArrayList<Integer>>();
		int num_instances=0;

		ArrayList<Integer> max = new ArrayList<Integer>();

		for(int j=0; j<num_nodes; j++){
			max.add(0);}
		ArrayList<Integer> clas= new ArrayList<Integer>(n_instances);



		while(scanner.hasNextLine()){

			Scanner sca = new Scanner(scanner.nextLine());
			sca.useDelimiter(",");

			num_instances++;
			ArrayList<Integer> list = new ArrayList<Integer>();
			ArrayList<Integer> list_tot = new ArrayList<Integer>();

			int i=0;
			while(sca.hasNext()){
				i++;
				if(sca.hasNextInt()){
					int n=sca.nextInt();
					list_tot.add(n);
					if(i-1==num_nodes-1)  clas.add(n);
					else list.add(n);
					if(n>max.get(i-1)) max.set(i-1, n);

				}

				else{
					String cla = sca.next();
					if(list_string.get(i-1).contains(cla)){
						int c = list_string.get(i-1).indexOf(cla);
						list_tot.add(c);
						if(i-1==num_nodes-1)  clas.add(c);
						else list.add(c);
						if(c > max.get(i-1))	max.set(i-1, c);
					}

					else{
						list_string.get(i-1).add(cla);
						int k = list_string.get(i-1).size()-1;
						list_tot.add(k);
						if(i-1==num_nodes-1)  clas.add(k);
						else list.add(k);
					}
				}

			}

			sca.close();



			instances_aux_tot.add(list_tot);
			instances_aux.add(list);}

		scanner.close();


		long seed = 9;
		java.util.Collections.shuffle(instances_aux_tot, new Random(seed));
		java.util.Collections.shuffle(instances_aux, new Random(seed));    





		X= new RandVect(num_nodes);

		for(int m =0; m <num_nodes; m++){
			X.attributes[m].r = max.get(m)+1;
			X.attributes[m].i=m;
		}

		ArrayList<ArrayList<Integer>> instances_train_aux = new ArrayList<ArrayList<Integer>>();
		ArrayList<ArrayList<Integer>> instances_test_aux = new ArrayList<ArrayList<Integer>>();
		ArrayList<ArrayList<Integer>> instances_train_aux_tot = new ArrayList<ArrayList<Integer>>();
		ArrayList<ArrayList<Integer>> instances_test_aux_tot = new ArrayList<ArrayList<Integer>>();

		int num_train =(int)Math.rint((double) num_instances * 0.8);




		for(int i=0; i < num_train ; i++){
			instances_train_aux.add(instances_aux.get(i));
			instances_train_aux_tot.add(instances_aux_tot.get(i));
		}



		for(int k=num_train; k<num_instances ; k++){
			instances_test_aux.add(instances_aux.get(k));
			instances_test_aux_tot.add(instances_aux_tot.get(k));
		}
		list_r=max;
		//instances_class=clas;
		instances_total=instances_aux_tot;

		instances = instances_aux;


		instances_train=instances_train_aux;

		//instances_train_total=instances_train_aux_tot;
		instances_test=instances_test_aux;

		instances_test_total=instances_test_aux_tot;

		n_instances=num_instances;
		n_nodes =num_nodes-1;


		//list_c=list_string;
		//n_train =n_instances-num_train;
	}


	//Created Data given instances
	public Data(ArrayList<ArrayList<Integer>> inst) {
		instances_total=inst;
		n_nodes=inst.get(0).size();
		n_instances=inst.size();
		X= new RandVect(n_nodes);

		for(int m =0; m <n_nodes; m++){
			X.attributes[m].i=m;
			X.attributes[m].r = 4;
		}

		//ArrayList<Integer> max = new ArrayList<Integer>();

		/*
		for(int j=0; j<n_nodes; j++){
			max.add(0);}

		for(int i=0; i <n_instances; i++) {
			for(int j=0; j <n_nodes; j++) {
				if(inst.get(i).get(j)>max.get(j)) max.set(j, inst.get(i).get(j));

			}
		}


		ArrayList<Integer> list_r_new = new ArrayList<Integer>();

		for(int i=0;i<n_nodes;i++) {

			list_r_new.add(4);
		}
		//list_r=max
		list_r=list_r_new;

			X= new RandVect(n_nodes);

			for(int m =0; m <n_nodes; m++){
				X.attributes[m].r = 4;
						//max.get(m)+1;
				X.attributes[m].i=m;
			}*/

	}





	//Creates a copy of data
	public Data(Data data) {

		X = new RandVect(data.X);
		n_nodes = data.n_nodes;
		n_instances = data.n_instances;
		ArrayList<ArrayList<Integer>> inst = new ArrayList<ArrayList<Integer>>();
		for(int i=0; i< data.n_instances; i++) {
			ArrayList<Integer> in = new ArrayList<Integer>(data.instances_total.get(i));
			inst.add(in);}
		instances_total = inst;
		list_r = new ArrayList<Integer>(data.list_r);
		//string = new String(data.string);
	}





	/*public void takeNodeC(){
		n_nodes=n_nodes-1;
		for(int i=0;i<n_instances;i++){
			instances.get(i).remove(n_nodes);
		}

		X= new RandVect(n_nodes);

		for(int m =0; m <n_nodes ; m++){
			X.attributes[m].r = list_r.get(m)+1;
			X.attributes[m].i=m;

		}
		}*/


	public Data(int n){
		n_nodes=n;
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i=0;i<n_nodes;i++){
			list.add(1);
		}
		X= new RandVect(n_nodes);

		for(int m =0; m <n_nodes; m++){
			X.attributes[m].r = list.get(m)+1;
			X.attributes[m].i=m;
		}


	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((X == null) ? 0 : X.hashCode());
		result = prime * result + ((instances == null) ? 0 : instances.hashCode());
		result = prime * result + ((instances_test == null) ? 0 : instances_test.hashCode());
		result = prime * result + ((instances_test_total == null) ? 0 : instances_test_total.hashCode());
		result = prime * result + ((instances_total == null) ? 0 : instances_total.hashCode());
		result = prime * result + ((instances_train == null) ? 0 : instances_train.hashCode());
		result = prime * result + ((instances_train_total == null) ? 0 : instances_train_total.hashCode());
		result = prime * result + ((list_r == null) ? 0 : list_r.hashCode());
		result = prime * result + n_instances;
		result = prime * result + n_nodes;
		result = prime * result + n_train;
		result = prime * result + ((string == null) ? 0 : string.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Data other = (Data) obj;
		if (X == null) {
			if (other.X != null)
				return false;
		} else if (!X.equals(other.X))
			return false;
		if (instances == null) {
			if (other.instances != null)
				return false;
		} else if (!instances.equals(other.instances))
			return false;
		if (instances_test == null) {
			if (other.instances_test != null)
				return false;
		} else if (!instances_test.equals(other.instances_test))
			return false;
		if (instances_test_total == null) {
			if (other.instances_test_total != null)
				return false;
		} else if (!instances_test_total.equals(other.instances_test_total))
			return false;
		if (instances_total == null) {
			if (other.instances_total != null)
				return false;
		} else if (!instances_total.equals(other.instances_total))
			return false;
		if (instances_train == null) {
			if (other.instances_train != null)
				return false;
		} else if (!instances_train.equals(other.instances_train))
			return false;
		if (instances_train_total == null) {
			if (other.instances_train_total != null)
				return false;
		} else if (!instances_train_total.equals(other.instances_train_total))
			return false;
		if (list_r == null) {
			if (other.list_r != null)
				return false;
		} else if (!list_r.equals(other.list_r))
			return false;
		if (n_instances != other.n_instances)
			return false;
		if (n_nodes != other.n_nodes)
			return false;
		if (n_train != other.n_train)
			return false;
		if (string == null) {
			if (other.string != null)
				return false;
		} else if (!string.equals(other.string))
			return false;
		return true;
	}

 }