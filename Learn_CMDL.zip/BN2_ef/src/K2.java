import java.util.ArrayList;


public class K2 extends Score {


	//Computes K2
	@Override
	public double evaluate(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {	 
		float[][]  conf =by.Configuracao(instances);
		float[][]  nij =by.Nij(instances,conf);
		double sum=0;
		float a1=1,a4=1;
		int a2=1;


		for(int i=0; i<by.n; i++){			  
			for(int j=0; j<by.nodes_rv.get(i).q; j++){

				a1= nij[i][j]+by.nodes_rv.get(i).r-1;
				a2= by.nodes_rv.get(i).r-1;

				for(int m=1 ; m<=a1; m++){
					sum-=Math.log(m)/Math.log(2);

				}

				for(int h=1; h<=a2 ;h++ ){
					sum+=Math.log(h)/Math.log(2);
				}


				for(int k=0; k<by.nodes_rv.get(i).r; k++){
					a4= conf[i][j*by.nodes_rv.get(i).r+k];

					for(int r=1; r<=a4;r++){
						sum+=Math.log(r)/Math.log(2);
					}


				}
			}
		}

		return sum;  

	}

	public double[] param(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {

		double[] out = new double[1];
		out[0]=0;
		return out;
	}





}
