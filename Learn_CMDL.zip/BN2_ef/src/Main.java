import java.io.*;



public class Main {

	public static void main(String[] args) throws  IOException {


		// Data set iris-Discretize-Rfirst-last-rp.csv saved in "/home/margarida/Documents/datasets"
		Data data = new Data("/home/margarida/Documents/datasets/iris-Discretize-Rfirst-last-rp.csv");


		//Choose a Score
		Score CMDL = new CMDL();


		//Number of random restarts for the greedy hill climber 
		int n=600;


		//Greedy Hill Climber Algorithm for Data data, with instances data.instances_total,CMDL as scoring 
		//function and n random restarts
		Graph g_cmdl = Train.ghc(data,data.instances_total,CMDL,n);

		BN b_cmdl = new BN(g_cmdl,data);

		//Print Score
		System.out.println(CMDL.evaluate(data.instances_total, b_cmdl, data));

		//Print nodes
		System.out.println(g_cmdl.nodes);


		//Print adjacency matrix
		System.out.println(g_cmdl.adj);

		//Write to .dot file "output"
		Util.writeGraph2(g_cmdl,"output");


		





	}


}

