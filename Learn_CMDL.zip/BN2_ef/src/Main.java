import java.io.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;
import java.util.Arrays;




public class Main {
	
	
	// Generates parameters for Graph g; Each attribute has s states. 
	
	public static Hashtable<ArrayList<Integer>,Double> gen_prob(Graph g, int s){

		Random r = new Random();

		// Save P(X|Y)
		Hashtable<ArrayList<Integer>,Double> h = new Hashtable<ArrayList<Integer>,Double>();

		for (int i=0; i<g.n;i++){
			if(g.parents.get(i).size()>0){
				for (int j=0; j<Math.pow(s,g.parents(i).size());j++){
					float sum = 0;
					for(int k=0; k<s ; k++) {
					Double t =r.nextDouble();
					ArrayList<Integer> l = new ArrayList<Integer>();
					l.add(i);
					l.add(j);
					l.add(k);
				h.put(l,t);
				sum+=t;
					}
				
				for (int k=0;k<s;k++){
					ArrayList<Integer> l = new ArrayList<Integer>();
					l.add(i);
					l.add(j);
					l.add(k);
				double f = h.get(l)/sum;
				h.put(l, f);

				}

			}
			}
			
			else {
				float sum2 =0;
				for(int j=0; j<s; j++) {
				Double t=r.nextDouble();
				ArrayList<Integer> l = new ArrayList<Integer>();
				l.add(i);
				l.add(j);
				h.put(l, t);
				sum2+=t;
				
			}
				
				for(int j=0; j<s; j++) {
					ArrayList<Integer> l = new ArrayList<Integer>();
					l.add(i);
					l.add(j);
					Double f =h.get(l)/sum2;
					h.put(l, f);
					
				}
		
		}
			
			
			
		}

		return h;


	}
	
	// Samples n instances from Graph g with parameters h
	
	public static ArrayList<ArrayList<Integer>> getinstances(Graph g,int n,Hashtable<ArrayList<Integer>,Double> h,int s){

	
		Random r = new Random();

		ArrayList<ArrayList<Integer>> set = new ArrayList<ArrayList<Integer>>();

		for(int m=0; m<n;m++){

			ArrayList<Integer> instance = new ArrayList<Integer>();


			for(int i=0; i<g.n; i++){
				instance.add(0);
			}
			
			

			for (int i=0; i<g.n;i++){
				
				if(g.parents.get(i).size()==0){
					
					
					double f = r.nextDouble();
					double sum =0;
					
					for(int p=0; p < s; p++) {
						ArrayList<Integer> l= new ArrayList<Integer>();
						l.add(i);
						l.add(p);
						Double prob = h.get(l);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;
	
					}
					
					
				}
			}

			for (int i=0; i<g.n;i++){
				if(g.parents.get(i).size()!=0){
					
					int valor_j=instance.get(g.parents.get(i).get(0));
					for (int j=1; j<g.parents(i).size();j++){
						valor_j=valor_j*2;
						valor_j=valor_j+instance.get(g.parents.get(i).get(j));
					}
					float f = r.nextFloat();
					float sum =0;
					
					for(int p=0; p < s; p++) {
						ArrayList<Integer> l2= new ArrayList<Integer>();
						l2.add(i);
						l2.add(valor_j);
						l2.add(p);
						Double prob = h.get(l2);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;
	
					}
				}
				
			}
			set.add(instance);

		}

		return set;
	}

	
	
	//Adds n to instances from Graph g with parameters h
	
	public static ArrayList<ArrayList<Integer>> addinstances(Graph g,int n,ArrayList<ArrayList<Integer>> instances,Hashtable<ArrayList<Integer>,Double> h,int s){

		Random r = new Random();
		//r.setSeed(2);

		for(int m=0; m<n;m++){

			ArrayList<Integer> instance = new ArrayList<Integer>();


			for(int i=0; i<g.nodes.size(); i++){
				instance.add(0);
			}

				for (int i=0; i<g.n;i++){
				
				if(g.parents.get(i).size()==0){
				
					
					float f = r.nextFloat();
					float sum =0;
					
					for(int p=0; p < s; p++) {
						ArrayList<Integer> l= new ArrayList<Integer>();
						l.add(i);
						l.add(p);
						Double prob = h.get(l);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;
	
					}
					
					
				
					
				}
			}
			
			for (int i=0; i<g.nodes.size();i++){
				if(g.inEdges(i).size()>0){

				
					int valor_j=instance.get(g.inEdges(i).get(0));
					for (int j=1; j<g.parents(i).size();j++){
						valor_j=valor_j*2;
						valor_j=valor_j+instance.get(g.inEdges(i).get(j));
					}


					double f = r.nextDouble();
					double sum =0;
					
					for(int p=0; p < s; p++) {
						ArrayList<Integer> l2= new ArrayList<Integer>();
						l2.add(i);
						l2.add(valor_j);
						l2.add(p);
						Double prob = h.get(l2);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;
	
					}

			

				}

			}
			instances.add(instance);

		}

		return instances;

	}

	public static void main(String[] args) throws  IOException {
		
		// Input data
		Data data = new Data("/Users/margaridasousa/Desktop/led_500.csv");
		
		
		// Choose a score
		Score CMDL = new LL();
		
		
		//Number of random restarts for the greedy hill climber
		int n=1000;
		
		
		//Greedy Hill Climber Algorithm for Data data, with instances data.instances_total,CMDL as scoring 
		Graph g_cmdl = Train.ghc(data,data.instances_total,CMDL,n);
		
		
		BN b_cmdl = new BN(g_cmdl,data);
		
		
		//Print Score
		System.out.println(CMDL.evaluate(data.instances_total, b_cmdl, data));
		
		
		//Print nodes
		System.out.println(g_cmdl.nodes);
		
		
		
		//Print adjacency matrix
		System.out.println(g_cmdl.adj);
		
		
		
		//Write to .dot file "output"
		//Util.writeGraph2(g_cmdl,"output");   


	}



}

