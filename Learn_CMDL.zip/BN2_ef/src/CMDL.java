import java.util.ArrayList;



public class CMDL extends Score {



	// Computes CMDL
	@Override
	public double evaluate(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {


		Graph g2= new Graph(by.g);
		if(!g2.istree()) {
			g2.forestification();
		}

		BN b2 = new BN(g2,data);

		float[][]  conf_for =b2.Configuracao(instances);

		float[][]  nij_for =b2.Nij(instances,conf_for);


		double sum=0;


		for(int i=0; i<b2.n ; i++) {
			for(int j=0; j<b2.nodes_rv.get(i).q; j++) {
				float a1 = nij_for[i][j]+b2.nodes_rv.get(i).r-1;
				float a3 =b2.nodes_rv.get(i).r-1;


				for(int m=1 ; m<=a1; m++){
					sum-=Math.log(m)/Math.log(2);

				}

				for(int m=1 ; m<=a3; m++){
					sum+=Math.log(m)/Math.log(2);

				}


				for(int k=0; k<b2.nodes_rv.get(i).r;k++) {
					float a2= conf_for[i][j*b2.nodes_rv.get(i).r+k];

					for(int m=1; m<=a2; m++) {
						sum+=Math.log(m)/Math.log(2);

					}

				}  

			}
		}

		return sum;  

	}


	@Override
	public double[] param(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {
		double[] out = new double[3];

		Graph g2= new Graph(by.g);
		if(!g2.istree()) {
			g2.forestification();
		}

		BN b2 = new BN(g2,data);

		float[][] conf_for =b2.Configuracao(instances);

		float[][]  nij_for =b2.Nij(instances,conf_for);

		double par=0;
		double ll=0;
		float a2=1;


		for(int i=0; i<b2.n ; i++) {
			for(int j=0; j<b2.nodes_rv.get(i).q; j++) {
				float a1 = nij_for[i][j];
				float a3=nij_for[i][j]+b2.nodes_rv.get(i).r-1;
				float a4=b2.nodes_rv.get(i).r-1;



				for(int m=1 ; m<=a1; m++){
					ll+=Math.log(m)/Math.log(2);
					par-=Math.log(m)/Math.log(2);

				}

				for(int m=1;m<=a3;m++) {
					par+=Math.log(m)/Math.log(2);
				}

				for(int m=1;m<=a4;m++) {
					par-=Math.log(m)/Math.log(2);
				}





				for(int k=0; k<b2.nodes_rv.get(i).r;k++) {
					a2= conf_for[i][j*b2.nodes_rv.get(i).r+k];

					for(int m=1; m<=a2; m++) {
						ll-=Math.log(m)/Math.log(2);

					}

				}  

			}
		}


		out[0]=par;
		out[1]=ll;
		out[2]=par+ll;
		return out;  

	}


}