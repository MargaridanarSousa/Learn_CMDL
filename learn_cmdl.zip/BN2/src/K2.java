import java.util.ArrayList;


public class K2 extends Score {
	
	
	//Computes K2
	@Override
	public double evaluate(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {	 
		  //Transform(g);
		  ArrayList<ArrayList<Float>> conf =by.Configuracao(instances);
		  ArrayList<ArrayList<Float>> nij =by.Nij(instances);
		  double soma=0;
		  //double ll=0;
		  //double par=0;
		  for(int i=0; i<by.n; i++){			  
			  for(int j=0; j<by.nodes_rv.get(i).q; j++){
				  
				  float a1= nij.get(i).get(j)+by.nodes_rv.get(i).r-1;
				  int a2= by.nodes_rv.get(i).r-1;
				  //float a3= nij.get(i).get(j);
				  
				  for(int m=1 ; m<=a1; m++){
					  soma-=Math.log(m)/Math.log(2);
				
				  }
		
				  for(int h=1; h<=a2 ;h++ ){
					  soma+=Math.log(h)/Math.log(2);
				  }
				  
				  
				  for(int k=0; k<by.nodes_rv.get(i).r; k++){
				  float a4= conf.get(i).get(j*by.nodes_rv.get(i).r+k);

				 for(int r=1; r<=a4;r++){
					 soma+=Math.log(r)/Math.log(2);
				 }
				 
				    
				     }
				  }
		  }

		 return soma;  
		
	}
	
	public double[] param(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {
		
		double[] out = new double[1];
		out[0]=0;
		return out;
	}
	
	

	

}
