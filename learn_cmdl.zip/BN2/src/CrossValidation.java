import java.util.ArrayList;
import java.lang.Math;


public class CrossValidation {
	  
	private static int folds;
		
	
		//Perform cross validation with k-folds
	
	    public static float CV(Data data,int k,Score scorefun, int n_restarts) {
	  
	    folds=k;
	    
	    int p=(int)Math.rint((double) data.n_instances * (double)1/folds);
	    float score =0;
	    
	    
	    for(int f=0; f<folds;f++){
	    	
	    ArrayList<ArrayList<Integer>> train_aux = new  ArrayList<ArrayList<Integer>>();
	    ArrayList<ArrayList<Integer>> val_aux = new ArrayList<ArrayList<Integer>>();
	    ArrayList<ArrayList<Integer>> train_aux_tot = new  ArrayList<ArrayList<Integer>>();
	    ArrayList<ArrayList<Integer>> val_aux_tot = new ArrayList<ArrayList<Integer>>();	
	   	    	for(int j=0; j<f*p;j++){
	    		train_aux.add(data.instances.get(j));
	    		train_aux_tot.add(data.instances_total.get(j));
	    		
	    		}
	   
	   	    	
	    	for(int j=((int)Math.floor((double)f*p));j<Math.min((int)Math.floor((f+1)*p),data.n_instances);j++){
	    		val_aux.add(data.instances.get(j));
	    		val_aux_tot.add(data.instances_total.get(j));
	    	}
	    	
	    	for(int j=((int)Math.floor((f+1)*p))-1; j<data.n_instances ;j++){
	    		train_aux.add(data.instances.get(j));
	    		train_aux_tot.add(data.instances_total.get(j));
	    	}
	    	
	    Graph g = Train.ghc(data,train_aux,scorefun,n_restarts);
	    
	    
	    BN b = new BN(g,data);
	    
	    b.joinC(data);
	    
	    score+=Test.test(b,data,val_aux_tot);
	    
	 // System.out.println("Score:"+Test.test(b,data,val_aux_tot));
	   // System.out.println("Fold"+f+"done");\

	    
	    b.takeC();
       
     	
    	
	}
     
	  
	    
	    score = score / ((float) folds);
	 	 return  score;
	    
}
       	
       		  
	}
	    	
	    
	    	
	    	
	    	
	    
	     