import java.util.ArrayList;

public abstract class Score {
	
	public abstract double evaluate(ArrayList<ArrayList<Integer>> instances, BN b,Data data);

	

	public abstract double[] param(ArrayList<ArrayList<Integer>> instances, BN b,Data data);
}


