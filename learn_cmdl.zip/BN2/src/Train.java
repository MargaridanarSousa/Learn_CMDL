import java.util.ArrayList;
import java.util.Random;
import java.util.*;

public class Train {

// Greedy Hill Climber Algorithm 
	
	public static Graph ghc(Data data, ArrayList<ArrayList<Integer>> instances,Score scorefun,int n_restarts) {

		Random r = new Random();
		int n= instances.get(0).size();
		Graph g_1 = new Graph(n,r.nextInt(n));
		BN b_1 = new BN(g_1,data);
		double previous_best_score = new Double(scorefun.evaluate(instances,b_1,data));
		double best_score = previous_best_score;
		int best_op =0;
		int best_head=0;
		int best_tail=0;
		int c=0;
		Set<Graph> tabu = new HashSet<Graph>();	
		tabu.add(new Graph(g_1));
		Graph g_res = new Graph(g_1);	
		double res_score =best_score;
		

		while(c<n_restarts) {
			for(int i=0; i <n ; i++ ) {
				for(int j=0; j<n;j++) {
					for(int k=0; k<3; k++) {
						double score= b_1.op(i,j,k,instances,tabu,scorefun,data);
						if(score>best_score) {
							best_score=score;
							best_op=k;
							best_head=i;
							best_tail=j;

						}
					}

				}

			}
			
			if(best_score > previous_best_score) {


				if(best_op==0) b_1.add(best_head,best_tail);

				if(best_op==1) b_1.remove(best_head,best_tail);

				if(best_op==2) b_1.flip(best_head,best_tail);}

			if(previous_best_score>=best_score){
				
				c+=1;
				
				//System.out.println(c);
				
				int m =(int) Math.floor((float)n*(n-1)/(float)3);
				
				Graph g_rand = new Graph(n,r.nextInt(n));
				int e =1;
				while(!g_rand.isCovering()) {
					e =r.nextInt(m); 
					g_rand = new Graph(n,e);	
				}				
				b_1.g=g_rand;
				b_1.act(data);
				best_score=scorefun.evaluate(instances, b_1,data);

			} 


			if(best_score>res_score){
				g_res= new Graph(b_1.g);
				res_score= best_score;

			}
			tabu.add(new Graph(b_1.g));
			previous_best_score = best_score;
			best_score= previous_best_score;

		}
		System.out.println("Resultant network score: "+res_score);
		//bn b_res = new bn(g_res,data);
		return g_res;


	}

}
