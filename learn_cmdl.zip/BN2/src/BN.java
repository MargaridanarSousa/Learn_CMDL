import java.util.ArrayList;
import java.util.*;

public class BN {
	
	//Graph 
	protected Graph g;
	// Nodes in random variables
	protected ArrayList<RandVect>  nodes_rv;
	//Parents in random variables
	protected ArrayList<ArrayList<RandVect>> parents_rv;
	int n;

	
//Creates a new bayesian network
 public BN(Graph g2,Data data2) {
	 
	 g=g2;
	 n= g2.nodes.size();
	 nodes_rv = new ArrayList<RandVect>();
 		
 		
	 		for(int i=0; i<n;i++){
		 			RandVect list_rv= new RandVect(g2.nodes.get(i).size());
	 			
	             	int r=1;
	                for(int j=0;j< g2.nodes.get(i).size(); j++){
	 		    	list_rv.attributes[j]=data2.X.attributes[g2.nodes.get(i).get(j)];
	 		    	r=r*data2.X.attributes[g2.nodes.get(i).get(j)].r;
	 		    			}
	 		       list_rv.r=r;
	 		       list_rv.n=g2.nodes.get(i).size();  
	 		        int q=1;
	 			    for(int m=0; m<g2.parents.get(i).size();m++){
	 			    	for(int l=0; l<g2.nodes.get(g2.parents.get(i).get(m)).size();l++){
	 			    		q=q*data2.X.attributes[g2.nodes.get(g2.parents.get(i).get(m)).get(l)].r;
	 			    	
	 			    	}
	 			    	}
	 		
	 			    list_rv.q=q;
					 nodes_rv.add(list_rv);
	 		}
	 	
	 		        ArrayList<ArrayList<RandVect>> Par = new ArrayList<ArrayList<RandVect>>();
	 		        
	 		  for(int i=0; i<g2.nodes.size();i++) {
	 		         
	 		        ArrayList<RandVect> par = new ArrayList<RandVect>();
	 				for (int j=0; j<g2.parents.get(i).size();j++){
	 					par.add(nodes_rv.get(g2.parents.get(i).get(j)));
	 				}
	 				Par.add(par);	
	 		  }
	 		  parents_rv=Par;
 }
 
 
 
 
 
 
 public BN(Graph g2,Data data2,boolean b,ArrayList<ArrayList<Integer>> instances,BN by) {
	 
	 if(b==true) {
		 g=g2;
		 n= g2.nodes.size();
		 
		ArrayList<RandVect> nodes_rv_aux = new ArrayList<RandVect>(g2.nodes.size());
	 		
	 		
		 		for(int i=0; i<n;i++){
		 			
		 			RandVect list_rv = new RandVect(g2.nodes.get(i).size());
		 			
		             	int r=1;
		                for(int j=0;j< g2.nodes.get(i).size(); j++){
		 		    	list_rv.attributes[j]=data2.X.attributes[g2.nodes.get(i).get(j)];
		 		    	r=r*data2.X.attributes[g2.nodes.get(i).get(j)].r;
		 		    			}
		 		       list_rv.r=r;
		 		       list_rv.n=g2.nodes.get(i).size();
		 		       
		 		        int q=1;
		 			    for(int m=0; m<g2.parents.get(i).size();m++){
		 			    	for(int l=0; l<g2.nodes.get(g2.parents.get(i).get(m)).size();l++){
		 			    		q=q*data2.X.attributes[g2.nodes.get(g2.parents.get(i).get(m)).get(l)].r;
		 			    	}
		 			    	}
		 			    list_rv.q=q;
		 	
						 nodes_rv_aux.add(list_rv);
		 		}
		 		         nodes_rv=nodes_rv_aux;
		 		         
		 		        ArrayList<ArrayList<RandVect>> Par = new ArrayList<ArrayList<RandVect>>();
		 		        
		 		  for(int i=0; i<g2.nodes.size();i++) {
		 		         
		 		        ArrayList<RandVect> par = new ArrayList<RandVect>();
		 				for (int j=0; j<g2.parents.get(i).size();j++){
		 					par.add(nodes_rv.get(g2.parents.get(i).get(j)));
		 				}
		 				
		 				Par.add(par);
		 		  }
		 		  
		 		  parents_rv=Par;
	 }
	
	 
	 else {
		 
		 g=g2;
		 n= g2.nodes.size();
	 
	 
	 int n_instances = instances.size();
	 ArrayList<Integer> max = new ArrayList<Integer>();
	  for(int j=0; j<g2.n; j++){
			max.add(0);}

	  
	  for(int i=0; i< n_instances; i++){
   	   
    	  for(int j=0; j<g2.n;j++){
    		  
    		  if(g2.nodes.get(j).size()>0) {
    			  
int valor_j=instances.get(i).get(by.nodes_rv.get(g2.nodes.get(j).get(0)).attributes[0].i);
    			 
    			  for(int k=1; k <g2.nodes.get(j).size();k++) {
	  
		  valor_j=valor_j*by.nodes_rv.get(g2.nodes.get(j).get(k)).attributes[0].r;
		  valor_j=valor_j+ instances.get(i).get(by.nodes_rv.get(g2.nodes.get(j).get(k)).attributes[0].i);
		  
			  }
    			 if(max.get(j)<valor_j) max.set(j, valor_j);
    		  }
    		  
    		  else max.set(j, by.nodes_rv.get(g2.nodes.get(j).get(0)).attributes[0].r);
    		    
    	  }
    	  }
	  
	  ArrayList<RandVect> nodes_rv_aux = new ArrayList<RandVect>(g2.nodes.size());
	  
	  ArrayList<ArrayList<RandVect>> Par = new ArrayList<ArrayList<RandVect>>();
	  
 
 for(int j=0; j<g2.n;j++) {
	 
	
	  RandVect list_rv = new RandVect(g2.nodes.get(j).size());
	  
	  list_rv.r = max.get(j)+1;	 
	  
	  nodes_rv_aux.add(list_rv);
	 
 }
 

 
 
 for(int i=0; i<g2.n;i++) {
	 
	 ArrayList<RandVect> par = new ArrayList<RandVect>();
	 int q=1;
		for (int j=0; j<g2.parents.get(i).size();j++){
			par.add(nodes_rv_aux.get(g2.parents.get(i).get(j)));
			q=q*nodes_rv_aux.get(g2.parents.get(i).get(j)).r;
		}
		
		
		nodes_rv_aux.get(i).q=q;
		Par.add(par);
 
}
 
 parents_rv=Par;
 nodes_rv=nodes_rv_aux;

	 }
	 
	 
 }
 
 
 
 public void act(Data data) {
	 ArrayList<RandVect> nodes_rv_aux = new ArrayList<RandVect>(g.nodes.size());
		
		
		for(int i=0; i<n;i++){
			
			RandVect list_rv = new RandVect(g.nodes.get(i).size());
			
          	int r=1;
             for(int j=0;j< g.nodes.get(i).size(); j++){
		    	list_rv.attributes[j]=data.X.attributes[g.nodes.get(i).get(j)];
		    	r=r*data.X.attributes[g.nodes.get(i).get(j)].r;
		    			}
		       list_rv.r=r;
		       list_rv.n=g.nodes.get(i).size();
		       
		        int q=1;
			    for(int m=0; m<g.parents.get(i).size();m++){
			    	for(int l=0; l<g.nodes.get(g.parents.get(i).get(m)).size();l++){
			    		q=q*data.X.attributes[g.nodes.get(g.parents.get(i).get(m)).get(l)].r;
			    	}
			    	}
			    list_rv.q=q;
	
				 nodes_rv_aux.add(list_rv);
		}
		
		         nodes_rv=nodes_rv_aux;
		         
		        ArrayList<ArrayList<RandVect>> Par = new ArrayList<ArrayList<RandVect>>();
		        
		  for(int i=0; i<g.nodes.size();i++) {
		         
		        ArrayList<RandVect> par = new ArrayList<RandVect>();
				for (int j=0; j<g.parents.get(i).size();j++){
					par.add(nodes_rv.get(g.parents.get(i).get(j)));
				}
				
				Par.add(par);
		
				
		  }
		  
		  parents_rv=Par;
	 
	 
 }
 

 //Creates a copy of bn b 
 public BN(BN b) {
	 n = new Integer(b.n);
	 g= new Graph(b.g);
	 //data= new Data(b.data);
	 
	 ArrayList<RandVect> nodes = new ArrayList<RandVect>();
	 for(int i=0; i<n;i++) {
		 RandVect no = new RandVect(b.nodes_rv.get(i));
		 nodes.add(no);
	 }
	 nodes_rv = nodes;
	 
     
     ArrayList<ArrayList<RandVect>> Par = new ArrayList<ArrayList<RandVect>>();
     
     for(int i=0; i<n;i++) {
       
      ArrayList<RandVect> par = new ArrayList<RandVect>();
		for (int j=0; j<g.parents.get(i).size();j++){
			par.add(nodes_rv.get(g.parents.get(i).get(j)));
		}
		
		Par.add(par);

		
}
     parents_rv =Par;
	
	 /*ArrayList<ArrayList<RandVect>> parents = new ArrayList<ArrayList<RandVect>>();
	 for(int i=0; i<n; i++) {
		 ArrayList<RandVect> par = new ArrayList<RandVect>();
		 for(int j=0; j<b.parents_rv.get(i).size();j++) {
			 RandVect no = new RandVect(b.parents_rv.get(i).get(j));
			 par.add(no);
			 
		 }
		 parents.add(par);
	 }
	 
	 parents_rv = parents;*/
	 	 
 }

 
 // Add edge i -> j
 public void add(int i, int j) {
	 
	 g.addEdge(i, j);
	 
	 parents_rv.get(j).add(nodes_rv.get(i));
	 
	 nodes_rv.get(j).q=nodes_rv.get(j).q*nodes_rv.get(i).r;
	
 }
 
 
 //Remove edge i->j
 public void remove(int i, int j) {

	 g.removeEdge(i, j);
	 
	 parents_rv.get(j).remove(nodes_rv.get(i));
	 
	 nodes_rv.get(j).q=nodes_rv.get(j).q/nodes_rv.get(i).r;	
 }
 
 
 
 //Flips edge i->j
 public void flip(int i, int j) {
	remove(i,j);
	add(j,i);
 }
 
 
 //Joins node C (Class variable)
 public void joinC(Data data) {
	 n = n+1;
	 g.addC();
	 RandVect C = new RandVect(data.X.attributes[n-1]);
	 nodes_rv.add(C);
	 ArrayList<RandVect> p = new ArrayList<RandVect>();
	 parents_rv.add(p);
	 for(int i=0;i<n-1;i++) {
		 add(n-1,i);
	 }
 }
 
 //Removes node C (Class variable)
 public void takeC() {
	 n=n-1;
	 for(int i=0; i<n ; i++) {
		 remove(n,i);
	 }
	 g.takeC();
	 nodes_rv.remove(n);
	 parents_rv.remove(n);
	
	 
 }
 
 // Does one step of the greedy hill climber
 public  double op(int i,int j,int o,ArrayList<ArrayList<Integer>> instances,Set<Graph> tabu,Score scorefun,Data data) {

	 double score =-999999999;
		 
	 if(o==0) {
		if(i != j && !g.adj.get(i).contains(j)) {
		add(i,j);
		if(g.isCovering() && !tabu.contains(g)) {score=scorefun.evaluate(instances,this,data);
		
		}
		remove(i,j);}
	 }
	 
	 if(o==1) {
		 if(i != j && g.adj.get(i).contains(j)) {
			remove(i,j);
			if(g.isCovering() && !tabu.contains(g)) score=scorefun.evaluate(instances, this,data);
			add(i,j);}
		 }
	 
	 if(o==2) {
		 if( i != j && g.adj.get(i).contains(j) && !g.adj.get(j).contains(i)) {
			flip(i,j);
			if(g.isCovering() && !tabu.contains(g)) score=scorefun.evaluate(instances,this,data);
			flip(j,i);
		 }
	 }
	
	 return score;
 
 }
 
 
// Computes the Nijk vectors
public ArrayList<ArrayList<Float>> Configuracao(ArrayList<ArrayList<Integer>> instances){
	
	
	int n_instances = instances.size();
		
	ArrayList<ArrayList<Float>> conf = new ArrayList<ArrayList<Float>>(n);
	
	
		for(int i=0; i<n;i++){ 
	    
	      
			ArrayList<Float> list = new ArrayList<Float>();
			for(int j=0; j<nodes_rv.get(i).r*nodes_rv.get(i).q; j++){
				list.add((float)1);
			}
			conf.add(list);
		}
		
		
       for(int i=0; i< n_instances; i++){

     	  for(int j=0; j<n;j++){
     		  int valor_k= instances.get(i).get(nodes_rv.get(j).attributes[0].i);
     		 for(int k=1; k<=nodes_rv.get(j).n-1;k++){
     			  valor_k=valor_k*nodes_rv.get(j).attributes[k].r;
     			  valor_k=valor_k+ instances.get(i).get(nodes_rv.get(j).attributes[k].i);
     			}
     		  int valor_j=0; 
     		  
     		  if(parents_rv.get(j).size()>0){
     			  
     		  if(parents_rv.get(j).get(0).n==1){  
     			valor_j=instances.get(i).get(parents_rv.get(j).get(0).attributes[0].i);
     		  for(int l=1; l< parents_rv.get(j).size();l++){
     			  valor_j=valor_j*parents_rv.get(j).get(l).attributes[0].r;
     			  valor_j=valor_j+ instances.get(i).get(parents_rv.get(j).get(l).attributes[0].i);
     		  }
     		}
     			  else{
     				  valor_j=instances.get(i).get(parents_rv.get(j).get(0).attributes[0].i);
     			  for(int m=1; m<parents_rv.get(j).get(0).n;m++){
     			  valor_j=valor_j*parents_rv.get(j).get(0).attributes[m].r;
     			  valor_j=valor_j+ instances.get(i).get(parents_rv.get(j).get(0).attributes[m].i);
     				  }
                     }
     		  }     		  
     		  conf.get(j).set(valor_j*nodes_rv.get(j).r+valor_k, conf.get(j).get(valor_j*nodes_rv.get(j).r+valor_k)+1);

     	  }
       }
     		  
     	return conf;
     	
	}


public int[] getjs(int j,int s,int i) {
	int [] list_j = new int[s];
	int new_j =j;
	for(int l=s-1 ; l>=1; l--) {
		list_j[l]=new_j % parents_rv.get(i).get(l).r;
		new_j=(int)((double)new_j-list_j[l])/parents_rv.get(i).get(l).r;
	}
	
	list_j[0]=new_j;
	
	return list_j;
	
}


//Computes the Nij vectors
public ArrayList<ArrayList<Float>> Nij(ArrayList<ArrayList<Integer>> instances){
    
    
ArrayList<ArrayList<Float>> nij = new ArrayList<ArrayList<Float>>(n);
ArrayList<ArrayList<Float>> conf = Configuracao(instances);


for(int i=0; i<n;i++){
	ArrayList<Float> list = new ArrayList<Float>(nodes_rv.get(i).q);
	for(int j=0; j<nodes_rv.get(i).q; j++){
		float soma=0;
		for(int r=0; r<nodes_rv.get(i).r; r++){
			soma= soma + conf.get(i).get(j*nodes_rv.get(i).r+r);
		}
		list.add(soma);
	}
	nij.add(list);
}

return nij;
}


public ArrayList<ArrayList<Float>> teta(ArrayList<ArrayList<Integer>> instances){
	  ArrayList<ArrayList<Float>> conf = Configuracao(instances); 
  	 ArrayList<ArrayList<Float>> nij = Nij(instances); 
 ArrayList<ArrayList<Float>> teta_ijk = new ArrayList<ArrayList<Float>>(g.nodes.size());
  
  for(int i=0; i<n;i++){
  	ArrayList<Float> list_2 = new ArrayList<Float>(nodes_rv.get(i).q*nodes_rv.get(i).r);
  	
			for(int j=0; j<nodes_rv.get(i).q; j++){
				
				for(int r=0; r< nodes_rv.get(i).r; r++){
					
  float d1=conf.get(i).get(j*nodes_rv.get(i).r+r);
  float d2=(nij.get(i).get(j)); //+nodes_rv.get(i).r
  float d=d1/d2;
					list_2.add(d);
				}
			}
				teta_ijk.add(list_2);}
  return teta_ijk;
	}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((g == null) ? 0 : g.hashCode());
	result = prime * result + n;
	result = prime * result + ((nodes_rv == null) ? 0 : nodes_rv.hashCode());
	result = prime * result + ((parents_rv == null) ? 0 : parents_rv.hashCode());
	return result;
}


@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	BN other = (BN) obj;
	if (g == null) {
		if (other.g != null)
			return false;
	} else if (!g.equals(other.g))
		return false;
	if (n != other.n)
		return false;
	if (nodes_rv == null) {
		if (other.nodes_rv != null)
			return false;
	} else if (!nodes_rv.equals(other.nodes_rv))
		return false;
	if (parents_rv == null) {
		if (other.parents_rv != null)
			return false;
	} else if (!parents_rv.equals(other.parents_rv))
		return false;
	return true;
}

}
