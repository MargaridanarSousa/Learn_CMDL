public class RandVect {
	
	 public int n;
	 public RandVar[] attributes;    
	 public int r;
	 public int q;
	 
	 public RandVect(int nn) {
         
	        n = nn;
	        attributes=new RandVar[n];
	        for(int i=0; i < n; i++) attributes[i]= new RandVar();
	    }
	 
	 public RandVect(RandVar x) {
		 n=1;
		 attributes = new RandVar[1];
		 attributes[0]= x;
		 r=x.r;
		 q=1;
	 }
	 
	 
	 
	 
	 
	public RandVect(RandVect rv) {
	
		n = new Integer(rv.n);
		r= new Integer(rv.r);
		q = new Integer(rv.q);
		attributes= new RandVar[n];
		
		for(int i=0; i < n; i++) {attributes[i]= new RandVar(rv.attributes[i]);}
		
		
		
	}
	
	public void addNode(RandVar v) {
		n=n+1;
		attributes[n]= v;
		r=r*v.r;
		
		
	}
	
	

}
