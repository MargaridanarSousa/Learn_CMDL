import java.util.ArrayList;

public class LL extends Score {
	
	
	//Computes LL
	@Override
	public double evaluate(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {

		  ArrayList<ArrayList<Float>> conf = by.Configuracao(instances);
		  ArrayList<ArrayList<Float>> nij = by.Nij(instances);
		  double soma=0;

		  
		  for(int i=0; i<by.n;i++){

			  for(int j=0; j<by.nodes_rv.get(i).q; j++){

				  for(int r=0; r< by.nodes_rv.get(i).r; r++){
					  
					  double d1= conf.get(i).get(j*by.nodes_rv.get(i).r+r);
					  double d2=(double) nij.get(i).get(j);

					  
					  if(d1==0) soma+=0;
					  
					  else soma+=d1*(Math.log(d1)/Math.log(2)-Math.log(d2)/Math.log(2));


				  }
			  }
		  }
		  return soma;
	}

		  
		  
			@Override
			public double[] param(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {

				
				double[] out = new double[2];
				  ArrayList<ArrayList<Float>> conf = by.Configuracao(instances);
				  ArrayList<ArrayList<Float>> nij = by.Nij(instances);
				  //double soma=0;
				  double ll=0;
				  double par=0;
				  
		
				  
				  for(int i=0; i<by.n;i++){

					  for(int j=0; j<by.nodes_rv.get(i).q; j++){

						  for(int r=0; r< by.nodes_rv.get(i).r; r++){
							  
							  double d1= conf.get(i).get(j*by.nodes_rv.get(i).r+r);
							  double d2=(double) nij.get(i).get(j);

							  
							  
							  if(d1==0) ll+=0;
							  
							  else ll+=d1*(Math.log(d1)/Math.log(2)-Math.log(d2)/Math.log(2));


						  }
					  }
					 
				  }

				  out[0]=par;
				  out[1]=ll;
				  return out;
			}
		  
		  
		  
		  
	}