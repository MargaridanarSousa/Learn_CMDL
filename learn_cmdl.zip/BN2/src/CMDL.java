import java.util.ArrayList;



public class CMDL extends Score {
	
	
	
	// Computes CMDL
	
	@Override
	public double evaluate(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {

		
		Graph g2= new Graph(by.g);
		int n_instances = instances.size();
		 if(!g2.istree()) {
			 g2.forestification();
		 }

		  BN b2 = new BN(g2,data);
		  
		  ArrayList<ArrayList<Float>> conf_for =b2.Configuracao(instances);
		  
		  ArrayList<ArrayList<Float>> nij_for =b2.Nij(instances);
		  
		  //ArrayList<ArrayList<Float>> nij =by.Nij(instances);
		 
		  	  
		  double soma=0;

		  
		  for(int i=0; i<b2.n ; i++) {
			  for(int j=0; j<b2.nodes_rv.get(i).q; j++) {
				  float a1 = nij_for.get(i).get(j);
				  
				  
				  for(int m=1 ; m<=a1; m++){
					  soma-=Math.log(m)/Math.log(2);
					  
				  }
				  
				  for(int k=0; k<b2.nodes_rv.get(i).r;k++) {
					  float a2= conf_for.get(i).get(j*b2.nodes_rv.get(i).r+k);
					
					  for(int m=1; m<=a2; m++) {
						  soma+=Math.log(m)/Math.log(2);
						  
					  }
  
				  }  
				  
			  }
		  }
		  
		 
		  // Sanity check - PARAMETROS MDL
		  
		 for(int i=0; i<by.n ; i++) {
			  soma-= 0.5*(Math.log(n_instances)/Math.log(2))*(by.nodes_rv.get(i).r-1)*by.nodes_rv.get(i).q;
		  }

		  // New definition
		 
		  /*ArrayList<Set<Integer>> parents = new ArrayList<Set<Integer>>();
		  
		  for(int i=0; i <by.n ; i++) {
			  
			  Set<Integer> pare = new HashSet<Integer>(by.g.parents.get(i));
			  
			  //NOVATENTATIVA
			  
			 if(by.g.parents.get(i).size()>1 && !parents.contains(pare)) {
				 
				 
				 float n=n_instances;
				 
	
				for(int q=0; q<by.nodes_rv.get(i).q-1;q++) {
					soma-=Math.log(n)/Math.log(2);
					n-=nij.get(i).get(q);
					
				}
				parents.add(pare);
  
			  }

			  for(int j=0; j <by.nodes_rv.get(i).q; j++) {
				  float a3= nij.get(i).get(j)+by.nodes_rv.get(i).r-1;
				  float a4=nij.get(i).get(j);
				  float a5=by.nodes_rv.get(i).r-1;
				  
				  
				  for(int m=1; m<=a3; m++) {
					  soma-=Math.log(m)/Math.log(2); 
				  }
				  
				  for(int m=1; m<=a4; m++) {
					  soma+=Math.log(m)/Math.log(2); 
				  }
				  
				  for(int m=1; m<=a5; m++) {
					  soma+=Math.log(m)/Math.log(2); 
				  }
				  
				  
				  
				  
			  }
		  }*/
		  
		 return soma;  
		
	}
	
	
	@Override
	public double[] param(ArrayList<ArrayList<Integer>> instances, BN by,Data data) {
	double[] out = new double[3];
		
		Graph g2= new Graph(by.g);
		 if(!g2.istree()) {
			 g2.forestification();
		 }
		 
		  BN b2 = new BN(g2,data);
		  
		  ArrayList<ArrayList<Float>> conf_for =b2.Configuracao(instances);
		  
		  ArrayList<ArrayList<Float>> nij_for =b2.Nij(instances);
		  
		 // ArrayList<ArrayList<Float>> nij =by.Nij(instances);
		 
		  	  
		  //double soma=0;
		  double par=0;
		  double ll=0;

		  
		  for(int i=0; i<b2.n ; i++) {
			  for(int j=0; j<b2.nodes_rv.get(i).q; j++) {
				  float a1 = nij_for.get(i).get(j);
				  
				  
				  for(int m=1 ; m<=a1; m++){
					  ll+=Math.log(m)/Math.log(2);
					  
				  }
				  
				  for(int k=0; k<b2.nodes_rv.get(i).r;k++) {
					  float a2= conf_for.get(i).get(j*b2.nodes_rv.get(i).r+k);
					
					  for(int m=1; m<=a2; m++) {
						  ll-=Math.log(m)/Math.log(2);
						  
					  }
  
				  }  
				  
			  }
		  }
		  
		  //New definition for parameters
		  
 /* ArrayList<Set<Integer>> parents = new ArrayList<Set<Integer>>();
		  
		  for(int i=0; i <by.n ; i++) {
			  
			  Set<Integer> pare = new HashSet<Integer>(by.g.parents.get(i));
			  
			  //NOVATENTATIVA
			  
			 if(by.g.parents.get(i).size()>1 && !parents.contains(pare)) {
				 
				 
				 float n=n_instances;
				 
	
				for(int q=0; q<by.nodes_rv.get(i).q-1;q++) {
					par+=Math.log(n)/Math.log(2);
					n-=nij.get(i).get(q);
					
				}
				
				parents.add(pare);
				  

				  
			  }

			  for(int j=0; j <by.nodes_rv.get(i).q; j++) {
				  float a3= nij.get(i).get(j)+by.nodes_rv.get(i).r-1;
				  float a4=nij.get(i).get(j);
				  float a5=by.nodes_rv.get(i).r-1;
				  
				  
				  for(int m=1; m<=a3; m++) {
					  par+=Math.log(m)/Math.log(2); 
				  }
				  
				  for(int m=1; m<=a4; m++) {
					  par-=Math.log(m)/Math.log(2); 
				  }
				  
				  for(int m=1; m<=a5; m++) {
					  par-=Math.log(m)/Math.log(2); 
				  } 
			  }
		  }*/
		  

		  //Sanity check - MDL parameters 
		  for(int i=0; i<by.n ; i++) {
			  par+= 0.5*(Math.log(instances.size())/Math.log(2))*(by.nodes_rv.get(i).r-1)*by.nodes_rv.get(i).q;
		  }
		  
		  //New definition for parameters
		  
		/*  for(int i=0; i <by.n ; i++) {
			  for(int j=0; j <by.nodes_rv.get(i).q; j++) {
				  float a3= nij.get(i).get(j)+by.nodes_rv.get(i).r-1;
				  float a4=nij.get(i).get(j);
				  float a5=by.nodes_rv.get(i).r-1;
				  
				  
				  for(int m=1; m<=a3; m++) {
					  par+=Math.log(m)/Math.log(2); 
				  }
				  
				  for(int m=1; m<=a4; m++) {
					  par-=Math.log(m)/Math.log(2); 
				  }
				  
				  for(int m=1; m<=a5; m++) {
					  par-=Math.log(m)/Math.log(2); 
				  }
				  
				  
				  
				  
			  }
		  }*/
		  
		  out[0]=par;
		  out[1]=ll;
		  out[2]=par+ll;
		 return out;  
		
	}


}