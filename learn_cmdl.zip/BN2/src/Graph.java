import java.util.ArrayList;
import java.util.Stack;
import java.lang.Integer;
import java.util.Random;

public class Graph {

	protected  int n;
	protected  ArrayList<ArrayList<Integer>> adj;
	protected  ArrayList<ArrayList<Integer>> nodes;
	protected  ArrayList<ArrayList<Integer>> parents;

	public  Graph(int n0){
		n = n0;
		adj = new ArrayList<ArrayList<Integer>>();
		nodes = new ArrayList<ArrayList<Integer>>();
		parents= new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < n; i++){
			ArrayList<Integer> adj_i= new ArrayList<Integer>();
			ArrayList<Integer> l = new ArrayList<Integer>();
			ArrayList<Integer> p_i= new ArrayList<Integer>();
			
			l.add(i);
			adj.add(adj_i);
			nodes.add(l);
			parents.add(p_i);
		}
	}
	
	public boolean istree() {
		boolean b =true;
		int i =0;
		
	while (b==true && i <n) {
		if(parents.get(i).size()>0) b=false;
		i+=1;
		
	}
	
	return b;
	}

	
	
	public Graph(Graph g){
		n= g.n;
		adj= new ArrayList<ArrayList<Integer>>();
		nodes= new ArrayList<ArrayList<Integer>>();
		parents= new ArrayList<ArrayList<Integer>>();
		for(int i=0; i<n;i++) {
			ArrayList<Integer> a= new  ArrayList<Integer>(g.adj.get(i));
			ArrayList<Integer> n= new  ArrayList<Integer>(g.nodes.get(i));
			ArrayList<Integer> p= new  ArrayList<Integer>(g.parents.get(i));
			adj.add(a);
			nodes.add(n);
			parents.add(p);
			
		}
	}
	
	public void addC() {
		n=n+1;
		ArrayList<Integer> no = new ArrayList<Integer>();
		no.add(n-1);
		nodes.add(no);
		ArrayList<Integer> a = new ArrayList<Integer>();
		adj.add(a);
		ArrayList<Integer> p = new ArrayList<Integer>();
		parents.add(p);
	
		
	}
	
	public void takeC() {
		n=n-1;
		nodes.remove(n);
		adj.remove(n);
		parents.remove(n);
		
	}

	public int getn(){
		return n;
	}

	public ArrayList<ArrayList<Integer>> getadj(){
		return adj;
	}


	public ArrayList<ArrayList<Integer>> getnodes(){
		return nodes;
	}
	
	
	public void addEdge(int i, int j) {
			adj.get(i).add(j);
			parents.get(j).add(i);
	}


	public void removeEdge(int i, int j) {
		if(adj.get(i).contains(j)) {
			adj.get(i).remove(new Integer(j));
		}
		
		
		if(parents.get(j).contains(i)) {
			parents.get(j).remove(new Integer(i));
		}
		
	
	}
	
	
	public int getN() {return n;}

	public void flipEdge(int i, int j){
		if(adj.get(i).contains(j)){
			removeEdge(i,j);
			addEdge(j,i);

		}
	}

	public boolean hasEdge(int i, int j) {
		return adj.get(i).contains(j);
	}

	ArrayList<Integer> outEdges(int i) {
		return adj.get(i);
	}

	ArrayList<Integer> inEdges(int i) {
		return parents.get(i);
	}

	ArrayList<ArrayList<Integer>> parents(int i){
		ArrayList<ArrayList<Integer>> p = new ArrayList<ArrayList<Integer>>();
		for(int j=0; j<parents.get(i).size();j++) {
		p.add(nodes.get(parents.get(i).get(j)));}
		return p;}
	
	
	//Generates a graph with V nodes and E edges
	public Graph(int V, int E) {
	
	        if (E > (long) V*(V-1)) throw new IllegalArgumentException("Too many edges");
	        if (E < 0)              throw new IllegalArgumentException("Too few edges");
	        n=V;
	        adj = new ArrayList<ArrayList<Integer>>();
	        nodes = new ArrayList<ArrayList<Integer>>();
	        parents = new ArrayList<ArrayList<Integer>>();
	        ArrayList<Integer> perm_nodes= new ArrayList<Integer>();
			for (int i = 0; i < n; i++){
				ArrayList<Integer> adji= new ArrayList<Integer>();
				ArrayList<Integer> list = new ArrayList<Integer>();
				ArrayList<Integer> p= new ArrayList<Integer>();
				list.add(i);
				nodes.add(list);
				adj.add(adji);
				parents.add(p);
				perm_nodes.add(i);
				
			}
			
			java.util.Collections.shuffle(perm_nodes);
			
			
			Random rand = new Random();
	        int m=0;
	        while (m < E) {
	            int v = rand.nextInt(n);
	            int w = rand.nextInt(n);
	            //adj.get(v).size()==0
	            
	            if (v<w && !adj.get(perm_nodes.get(v)).contains(w) && !parents.get(perm_nodes.get(w)).contains(perm_nodes.get(v))) {
	               addEdge(perm_nodes.get(v),perm_nodes.get(w)); m++;
	            }
	        }
	        
	        
	      if(!isCovering()){
	        for(int i=0; i<n ; i++){
				for(int j=i+1; j<n;j++ ){
					int h=0;
					while(h<parents.get(j).size()){
						if(parents.get(i).contains(parents.get(j).get(h))){
							
							for(int k=0; k<parents.get(j).size();k++){
								if(!parents.get(i).contains(parents.get(j).get(k)) && parents.get(j).get(k)!=i && !parents.get(j).contains(i)  ) addEdge(parents.get(j).get(k),i);
								}
							for(int l=0; l<parents.get(i).size();l++){
								if(!parents.get(j).contains(parents.get(i).get(l)) && parents.get(i).get(l)!=i && !parents.get(j).contains(i) ) addEdge(parents.get(i).get(l),j);
								}
							break;
							}
						h++;
					}
					
					}
				}
	        }
			
	        }
				
	       

	/* Computes the SCC of the graph by Tarjan's Algorithm */	
	public ArrayList<ArrayList<Integer>> TarjanSCC() {

		ArrayList<ArrayList<Integer>> sccComp;
		boolean[] marked;        // marked[v] = has v been visited?
		int[] low;               // low[v] = low number of v
		int pre;                 // preorder number counter
		int count;               // number of strongly-connected components
		Stack<Integer> stack;    // stack

		sccComp = new ArrayList<>();
		int n= this.n;
		pre=0;
		count=0;
		marked = new boolean[n];
		stack = new Stack<Integer>();
		low = new int[n];
		for (int v = 0; v <n ; v++) {
			if (!marked[v]) dfs(v,marked,low,pre,count,stack,sccComp);
		}
		return sccComp;
	}

	/* Computes the depth-first search */
	private void dfs(int v,boolean[] marked,int[] low, int pre, int count,Stack<Integer> stack,ArrayList<ArrayList<Integer>> sccComp) { 

		marked[v] = true;
		low[v] = pre++;
		int min = low[v];
		stack.push(v);
		for (int w : this.outEdges(v)) {

			if (!marked[w]) dfs(w,marked,low,pre,count,stack,sccComp);

			if (low[w] < min) min = low[w];
		}
		if (min < low[v]) {
			low[v] = min;
			return;
		}
		ArrayList<Integer> component = new ArrayList<Integer>();
		int w;
		do {
			w = stack.pop();
			component.add(w);
			low[w] =this.n;
		} while (w != v);
		count++;
		sccComp.add(component);
	}



	/* Is the graph DAG ? */

	public boolean isDAG(){
		boolean b=false;
		for(int i=0; i<adj.size(); i++){
			if(adj.get(i).contains(i)) return b;
		}
		return TarjanSCC().size()==n;
	}

	/* Is the Graph a Covering Graph ? */
	public boolean isCovering(){
		if(isDAG()== false) return false;
		boolean b=false;
        for(int i=0; i<n ; i++){
				for(int j=i+1; j<n;j++){
					int h=0;
					while(h<parents.get(j).size()){
						
						if(parents.get(i).contains(parents.get(j).get(h))){
							
							for(int k=0; k<parents.get(j).size();k++){
								if(!adj.get(parents.get(j).get(k)).contains(i) && !parents.get(j).contains(i)) return b;
								}
							
							for(int l=0; l<parents.get(i).size();l++){
								if(!adj.get(parents.get(i).get(l)).contains(j) && !parents.get(i).contains(j)) return b;
								}
							}
						h++;
					}
					}
				}
       return true;
  }
	
	public boolean isCovering2() {
		
		if(isDAG()== false) return false;
		boolean b = false;
		
		
		for(int i=0;i<n;i++) {
			if(parents.get(i).size()>1) {
				
				for(int j=0; j<parents.get(i).size()-1;j++) {
					
					
					
					if( !adj.get(parents.get(i).get(j)).containsAll(adj.get(parents.get(i).get(j+1))) ||
							!adj.get(parents.get(i).get(j+1)).containsAll(adj.get(parents.get(i).get(j)))	
							) {
						return b;
					
						
					}
		
		
	}
			}
			
			else return true;
		}
		return true;
	}
	
	


	/* Computes the Forestification relation */
	public void forestification(){
		
		boolean b=false;

		for(int v=0; v<n ; v++){
			
			if(parents.get(v).size()>=2){
				b=true;
				for(int i=0; i < parents.get(v).size()-1 ; i++){
				
				if(!adj.get(parents.get(v).get(i)).contains(parents.get(v).get(i+1))) addEdge(parents.get(v).get(i), parents.get(v).get(i+1));
				if(!adj.get(parents.get(v).get(i+1)).contains(parents.get(v).get(i))) addEdge(parents.get(v).get(i+1), parents.get(v).get(i));
				}
			}
		}
	
		if(b){

			ArrayList<ArrayList<Integer>> scc = TarjanSCC();
		
			Graph g2 = new Graph(scc.size());

			ArrayList<ArrayList<Integer>> nodes_c = new ArrayList<ArrayList<Integer>>();
			
			for(int i=0; i<scc.size();i++){
				

				ArrayList<Integer> lista_scc = new ArrayList<Integer>();

				for(int j=scc.get(i).size()-1; j>=0;j--){
					

					for (int k=nodes.get(scc.get(i).get(j)).size()-1; k>=0; k--){
						lista_scc.add(nodes.get(scc.get(i).get(j)).get(k));
					}
				}
				nodes_c.add(lista_scc);
			}
		

			g2.nodes=nodes_c;

			for(int i=0; i < scc.size();i++){
				for(int j=i+1; j<scc.size(); j++){
					for(int k=0; k<scc.get(i).size(); k++){
						for(int l=0; l<scc.get(j).size();l++){


							if(hasEdge(scc.get(i).get(k), scc.get(j).get(l)) && !g2.adj.get(i).contains(j) ){
								
								g2.addEdge(i,j);
								break;
							}

							if(hasEdge(scc.get(j).get(l), scc.get(i).get(k)) && !g2.adj.get(j).contains(i)){
								
								g2.addEdge(j,i);
								break;

							}
						}
					}
				}
			}
			
	
			

			/*ArrayList<ArrayList<ArrayList<Integer>>> adj_aux = new ArrayList<ArrayList<ArrayList<Integer>>>();

			for(int k=0; k< g2.n ; k++){

				ArrayList<ArrayList<Integer>> component = new ArrayList<ArrayList<Integer>>();

				for(int j=0; j < g2.adj[k].size() ; j++){

					component.add(nodes.get(g2.adj[k].get(j)));

				}
				adj_aux.add(component);
				g2.adj_nodes=adj_aux;	
			}*/
			n=g2.n;
			adj=g2.adj;
			nodes=g2.nodes;
			parents=g2.parents;
			
			//System.out.println("adj"+adj);
			
			
			
			//adj_nodes=g2.adj_nodes;
			forestification();
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adj == null) ? 0 : adj.hashCode());
		result = prime * result + n;
		result = prime * result + ((nodes == null) ? 0 : nodes.hashCode());
		result = prime * result + ((parents == null) ? 0 : parents.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Graph other = (Graph) obj;
		if (adj == null) {
			if (other.adj != null)
				return false;
		} else if (!adj.equals(other.adj))
			return false;
		if (n != other.n)
			return false;
		if (nodes == null) {
			if (other.nodes != null)
				return false;
		} else if (!nodes.equals(other.nodes))
			return false;
		if (parents == null) {
			if (other.parents != null)
				return false;
		} else if (!parents.equals(other.parents))
			return false;
		return true;
	}


	
	/*public void joinClass(){
	List<Integer>[] adj_aux = (List<Integer>[]) new List[n+1];
	adj_aux[n]= new ArrayList<Integer>();
	for (int i = 0; i < n; i++){
		adj_aux[i] =adj[i];
		adj_aux[n].add(i);}
	
	n=n+1;
	ArrayList<Integer> cla = new ArrayList<Integer>();
	cla.add(n-1);
	ArrayList<ArrayList<Integer>> nodes_aux = copynodes();
	nodes_aux.add(cla);
	
	
	nodes=nodes_aux;
	adj=adj_aux;
	}*/
	
	
	
	
	
	
	
	
	
}
	