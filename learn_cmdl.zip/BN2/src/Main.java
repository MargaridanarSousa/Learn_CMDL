// TODO Auto-generated method stub
import java.io.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.Hashtable;
import java.lang.Integer;


public class Main {

	public static float calc(int n){
		float res=0;
		for(int i=1; i<=n;i++){
			res+=Math.log(i);
		}
		return res;
	}
	
	
	
	// Generates parameters for Graph g; Each attribute has s states. 
	
	public static Hashtable<ArrayList<Integer>,Double> gen_prob(Graph g, int s){

		Random r = new Random();

		// Guardar P(X|Y)
		Hashtable<ArrayList<Integer>,Double> h = new Hashtable<ArrayList<Integer>,Double>();

		for (int i=0; i<g.n;i++){
			if(g.parents.get(i).size()>0){
				for (int j=0; j<Math.pow(s,g.parents(i).size());j++){
					float sum = 0;
					for(int k=0; k<s ; k++) {
					Double t =r.nextDouble();
					ArrayList<Integer> l = new ArrayList<Integer>();
					l.add(i);
					l.add(j);
					l.add(k);
				h.put(l,t);
				sum+=t;
					}
				
				for (int k=0;k<s;k++){
					ArrayList<Integer> l = new ArrayList<Integer>();
					l.add(i);
					l.add(j);
					l.add(k);
				double f = h.get(l)/sum;
				h.put(l, f);

				}

			}
			}
			
			else {
				float sum2 =0;
				for(int j=0; j<s; j++) {
				Double t=r.nextDouble();
				ArrayList<Integer> l = new ArrayList<Integer>();
				l.add(i);
				l.add(j);
				h.put(l, t);
				sum2+=t;
				
			}
				
				for(int j=0; j<s; j++) {
					ArrayList<Integer> l = new ArrayList<Integer>();
					l.add(i);
					l.add(j);
					Double f =h.get(l)/sum2;
					h.put(l, f);
					
				}
		
		}
			
			
			
		}

		return h;


	}
	
	// Samples n instances from Graph g with parameters h
	
	public static ArrayList<ArrayList<Integer>> getinstances(Graph g,int n,Hashtable<ArrayList<Integer>,Double> h,int s){

	
		Random r = new Random();

		ArrayList<ArrayList<Integer>> set = new ArrayList<ArrayList<Integer>>();

		for(int m=0; m<n;m++){

			ArrayList<Integer> instance = new ArrayList<Integer>();


			for(int i=0; i<g.n; i++){
				instance.add(0);
			}
			
			

			for (int i=0; i<g.n;i++){
				
				if(g.parents.get(i).size()==0){
					
					
					double f = r.nextDouble();
					double sum =0;
					
					for(int p=0; p < s; p++) {
						ArrayList<Integer> l= new ArrayList<Integer>();
						l.add(i);
						l.add(p);
						Double prob = h.get(l);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;
	
					}
					
					
				}
			}

			for (int i=0; i<g.n;i++){
				if(g.parents.get(i).size()!=0){
					
					int valor_j=instance.get(g.parents.get(i).get(0));
					for (int j=1; j<g.parents(i).size();j++){
						valor_j=valor_j*2;
						valor_j=valor_j+instance.get(g.parents.get(i).get(j));
					}
					float f = r.nextFloat();
					float sum =0;
					
					for(int p=0; p < s; p++) {
						ArrayList<Integer> l2= new ArrayList<Integer>();
						l2.add(i);
						l2.add(valor_j);
						l2.add(p);
						Double prob = h.get(l2);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;
	
					}
				}
				
			}
			set.add(instance);

		}

		return set;
	}

	
	
	//Adds n to instances from Graph g with parameters h
	
	public static ArrayList<ArrayList<Integer>> addinstances(Graph g,int n,ArrayList<ArrayList<Integer>> instances,Hashtable<ArrayList<Integer>,Double> h,int s){

		Random r = new Random();
		//r.setSeed(2);

		for(int m=0; m<n;m++){

			ArrayList<Integer> instance = new ArrayList<Integer>();


			for(int i=0; i<g.nodes.size(); i++){
				instance.add(0);
			}

				for (int i=0; i<g.n;i++){
				
				if(g.parents.get(i).size()==0){
				
					
					float f = r.nextFloat();
					float sum =0;
					
					for(int p=0; p < s; p++) {
						ArrayList<Integer> l= new ArrayList<Integer>();
						l.add(i);
						l.add(p);
						Double prob = h.get(l);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;
	
					}
					
					
				
					
				}
			}
			
			for (int i=0; i<g.nodes.size();i++){
				if(g.inEdges(i).size()>0){

				
					int valor_j=instance.get(g.inEdges(i).get(0));
					for (int j=1; j<g.parents(i).size();j++){
						valor_j=valor_j*2;
						valor_j=valor_j+instance.get(g.inEdges(i).get(j));
					}


					double f = r.nextDouble();
					double sum =0;
					
					for(int p=0; p < s; p++) {
						ArrayList<Integer> l2= new ArrayList<Integer>();
						l2.add(i);
						l2.add(valor_j);
						l2.add(p);
						Double prob = h.get(l2);
						if(sum <= f && f <= sum+prob) {
							instance.set(i,p);
							break;
						}
						sum+=prob;
	
					}

			

				}

			}
			instances.add(instance);

		}

		return instances;

	}

	/**
	 * @param args
	 * @throws IOException
	 */
	
	public static void main(String[] args) throws  IOException {
		
		String fileName = args[0];
	
		Data data = new Data(fileName);
		
		String score = args[1];
		
		
		int n = Integer.parseInt(args[2]);
		
		String outFile = args[3];
		
		System.out.println("Computing optimal network with "+score+" as scoring function and "+n+" random restarts!");

		Score SCORE;
		
		switch(score) {
		
		case "CMDL" :
			SCORE = new CMDL();
			break;
		
		case "MDL" :
			SCORE = new MDL();
			break;
			
		case "LL" :
			SCORE = new LL();
			break;
			
		case "K2":
			SCORE = new K2();
			break;
			
		default:
			SCORE = new CMDL();
			
		
		}
		
	
			
		
		Graph g = Train.ghc(data, data.instances_total, SCORE,n);
		

		
		StringBuilder sb = new StringBuilder();
		String ls = System.getProperty("line.separator");
		String dl = ls + ls;
		sb.append("digraph dbn{" + dl);
		
		for(int i=0; i<g.n; i++) {
			for(int j:g.adj.get(i)) {
				sb.append((i+1)+"->"+(j+1)+";");
				sb.append(dl);
			}
						
		}
		
		for(int i=0; i<g.n;i++) {
			sb.append((i+1)+";");
			sb.append(dl);
		}
		
		
		
		
		sb.append("}");
		
		File f = new File(outFile + ".dot");
		
		if (f.isFile()) {
			System.err.println("Warning: overwriting to " + outFile + ".");
		}
		
		PrintWriter w = new PrintWriter(f);
		
		w.println(sb);
		w.close();
		
		
		
	

	}

}


